#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <ctime>
#include "hash.h"

// convert string to lowercase
std::string strtolower(std::string str) {
    std::string::iterator c = str.begin() - 1, end = str.end();
    while(++c != end)
        *c = std::tolower(*c);
    return str;
}

// check if word is valid
bool isValidWord(std::string word) {
    for(char c : word)
        if((c < 'a' || c > 'z') && c != '-' && c != '\'')
            return false;
    return true;
}

// check if word has digits
bool hasDigits(std::string word) {
    for(char c : word)
        if(c >= '0' && c <= '9')
            return true;
    return false;
}

// check if character is valid word char; valid word characters are [a-z0-9\-']
// this is only used for splitting words, since 0-9 are ignored later
#define isWordChar(c) \
    ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '\'')

// split line into words (split by invalid word characters)
std::vector<std::string> splitWords(std::string line) {
    std::vector<std::string> words{};
    // set wordStart to strEnd when no valid word start set
    std::string::iterator wordEnd = line.begin(),
                          strEnd = line.end(),
                          wordStart = strEnd;

    if(!line.length())
        return words;

    while(wordEnd != strEnd) {
        if(isWordChar(*wordEnd) && wordStart == strEnd)
            wordStart = wordEnd;
        else if(!isWordChar(*wordEnd) && wordStart != strEnd) {
            words.push_back(std::string{wordStart, wordEnd});
            wordStart = strEnd;
        }
        wordEnd++;
    }
    if(wordStart != strEnd)
        words.push_back(std::string(wordStart, strEnd));

    return words;
}

int main() {
    std::ifstream dictStream, sourceStream;
    std::ofstream outStream;
    std::string dictPath, sourcePath, outPath, word, line;
    std::vector<std::string> words;
    std::clock_t startTime, finishDictTime, finishSpellCheckTime;
    hashTable dict{};
    int lineNumber = 1;

    // get sources
    std::cout << "Enter path to dictionary: ";
    std::cin >> dictPath;
    std::cout << "Enter path to source document: ";
    std::cin >> sourcePath;
    std::cout << "Enter path to output file: ";
    std::cin >> outPath;

    // fill map
    dictStream = std::ifstream{dictPath};
    startTime = clock();
    while(dictStream >> word)
        if(isValidWord(strtolower(word)) && word.length() <= 20)
            // error checking for debugging purposees
            if(dict.insert(strtolower(word)) == 2)
                std::cout << "Warning: rehash error" << std::endl;
    finishDictTime = clock();

    // check strings against map, write to output if problem
    sourceStream = std::ifstream{sourcePath};
    outStream = std::ofstream(outPath);
    while(std::getline(sourceStream, line)) {
        // break into words, parse each word
        words = splitWords(strtolower(line));
        for(std::string word : words) {
            // if word has digits, ignore
            if(hasDigits(word))
                continue;
            // if word length > 20 write error
            else if(word.length() > 20)
                outStream << "Long word at line " + std::to_string(lineNumber)
                          + ", starts: " + word.substr(0, 20)
                          << std::endl;
            // if word not in dictionary write error
            else if(!dict.contains(word))
                outStream << "Unknown word at line "
                          + std::to_string(lineNumber) + ": " + word
                          << std::endl;
        }
        lineNumber++;
    }
    finishSpellCheckTime = clock();

    // print timings to std output
    std::cout << "Reading dictionary elapsed time: "
              << double(finishDictTime - startTime) / CLOCKS_PER_SEC
              << "s" << std::endl
              << "Spell check elapsed time: "
              << double(finishSpellCheckTime - finishDictTime) / CLOCKS_PER_SEC
              << "s" << std::endl;
    return 0;
}
