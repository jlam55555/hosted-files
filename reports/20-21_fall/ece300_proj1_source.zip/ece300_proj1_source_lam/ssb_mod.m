% modulates a signal using the SSB AM scheme; currently assumes phase
% coherence (no pilot tone in modulated signal)
% params:
% f_c   = carrier frequency (Hz)
% A_c   = carrier amplitude
% sig_m = message signal
% f_s_m = message sampling frequency (Hz)
% f_s_c = carrier sampling frequency (Hz)
% ussb  = whether it is USSB (true for USSB, false for LSSB)
% returns:
% sig_c = SSB AM-modulated signal
function sig_c = ssb_mod(f_c, A_c, sig_m, f_s_m, f_s_c, is_ussb)
    duration = length(sig_m) / f_s_m;
    t_m = linspace(0, duration, length(sig_m));
    t_c = linspace(0, duration, f_s_c * duration);
    
    % upsample sig_m
    sig_m_us = interp1(t_m, sig_m, t_c);

    % generate in-phase component (same as DSB-SC AM-modulated signal)
    sig_dsbsc = sig_m_us .* cos(2 * pi * f_c * t_c);
    
    % generate quadrature component
    sig_mhat = hilbert_transform(sig_m_us);
    sig_quad = sig_mhat .* sin(2 * pi * f_c * t_c);
    
    if is_ussb
        sig_c = A_c * (sig_dsbsc - sig_quad);
    else
        sig_c = A_c * (sig_dsbsc + sig_quad);
    end
    
    % add pilot tone
    A_p = 1;
    sig_c = sig_c + A_p * cos(2 * pi * f_c * t_c);
end