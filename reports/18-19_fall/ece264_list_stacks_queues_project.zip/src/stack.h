#include "simplelist.h"

// Stack template: push inserts at start, pop removes from start
template <class T>
class Stack:public SimpleList<T> {
  public:
    Stack(std::string name);
    void push(T element);
    T pop();
};

template <class T>
Stack<T>::Stack(std::string name)
  : SimpleList<T>(name) { }

template <class T>
void Stack<T>::push(T element) {
  this->insert_at_start(element);
}

template <class T>
T Stack<T>::pop() {
  return this->remove_from_start();
}
