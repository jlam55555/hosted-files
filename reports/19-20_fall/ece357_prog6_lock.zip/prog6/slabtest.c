#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include "errfat.h"
#include "dll.h"
#include "slab.h"
#include "spinlock.h"
#include "stats.h"

#define THREAD_CNT 1000
#define SAMPLE_CNT 1000
#define SAMPLE_MAX 1000
char *PROG = "slabtest";

// check if dll is sorted and of correct length
void check_dll(struct dll *anchor, int exp_len, int is_seqlock) {
  struct dll *it, *it_fwd;
  int tot_cnt, err_cnt;
  
  dprintf(2, "=====\nSTRESS CHECK COMPLETE. CHECKING DLL.\n");
  for(it=anchor->fwd, it_fwd=it->fwd, tot_cnt=err_cnt=0; it!=anchor;
      it_fwd=(it=it_fwd)->fwd, tot_cnt++)
    if(it_fwd->value<it->value && it_fwd!=anchor) {
      printf("%d\n", it->value);
      err_cnt++;
    }
  dprintf(2, "=====\nOVERALL CHECK:\nSORTING ERRORS:\t%d\nDLL LENGTH:\t%d\n"
             "EXP DLL LENGTH:\t%d\nLENGTH ERROR:\t%d\n",
          err_cnt, tot_cnt, exp_len, (exp_len-tot_cnt)*(exp_len>tot_cnt?1:-1));
  if(is_seqlock)
    dprintf(2, "OPTIMISTIC SEQLOCK SUCCESS RATE: %d/%d (%f\%)\n",
            stats->suc_seqlock_read,
            stats->att_seqlock_read,
            ((float)stats->suc_seqlock_read)/stats->att_seqlock_read);
}

// driver for slab testing
struct stats *stats;
void generate_slab_test(int is_seqlock) {
  // att/suc_op_cnt: attempted and successful operation counts
  struct slab *slab;
  struct dll *dll, *p;
  struct timeval proc_start, proc_end;
  int i, wstatus, att_op_cnt[3], suc_op_cnt[3], net_len, pid;
  long elap_usec;

  struct dll *(*dll_insert)(struct dll *,int,struct slab *);
  int (*dll_delete)(struct dll *,struct dll *,struct slab *);
  struct dll *(*dll_find)(struct dll *,int);
  
  if(!(slab = slab_create()))
    ERR_FAT("slab_create", "main slab", "Error creating slab");
  if(!(dll = dll_create(slab)))
    ERR_FAT("dll_create", "main slab", "Error creating dll");

  // set up shared statistics memory region -- see stats.h
  stats_alloc();

  // get correct functions
  dprintf(2, "=====\n%s TEST\n", is_seqlock?"SEQLOCK":"SPINLOCK");
  dll_insert = is_seqlock?seq_dll_insert:spin_dll_insert;
  dll_delete = is_seqlock?seq_dll_delete:spin_dll_delete;
  dll_find = is_seqlock?seq_dll_find:spin_dll_find;

  memset(att_op_cnt, 0, 3*sizeof(int));
  memset(suc_op_cnt, 0, 3*sizeof(int));
  dprintf(2, "PROC\tATT INS\tATT DEL\tATT FND\tSUC INS\tSUC DEL\tSUC FND\t"
             "NET CHG\tELP TME\n");
  for(i = 0; i < THREAD_CNT; i++) {
    switch(fork()) {
    case -1:
      ERRNO_FAT("fork", i);
    case 0:
      srand(time(NULL)+i); // should generate unique seed for each proc
      gettimeofday(&proc_start, NULL);
      for(int j=0; j<SAMPLE_CNT; j++) {
        switch(rand()%3) {
        case 0:
          att_op_cnt[0]++;
          if((*dll_insert)(dll, rand()%SAMPLE_MAX, slab))
            suc_op_cnt[0]++;
          break;
        case 1:
          att_op_cnt[1]++;
          if((*dll_find)(dll, rand()%SAMPLE_MAX))
            suc_op_cnt[1]++;
          break;
        case 2:
          att_op_cnt[2]++;
          if((*dll_delete)(dll, dll_find(dll, rand()%SAMPLE_MAX), slab)>0)
            suc_op_cnt[2]++;
          break;
        }
      }
      gettimeofday(&proc_end, NULL);
      elap_usec = 1000000*(proc_end.tv_sec-proc_start.tv_sec)
                  + (proc_end.tv_usec-proc_start.tv_usec);
      dprintf(2, "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%6.03lfs\n",
              i, att_op_cnt[0], att_op_cnt[1], att_op_cnt[2],
              suc_op_cnt[0], suc_op_cnt[1], suc_op_cnt[2],
              suc_op_cnt[0]-suc_op_cnt[2],
              elap_usec/1e6);
      spin_lock(&stats->lock);
      stats->net_dll_len_chg += suc_op_cnt[0]-suc_op_cnt[2];
      spin_unlock(&stats->lock);
      exit(EXIT_SUCCESS);
    }
  }

  for(i=0; i<THREAD_CNT; i++) {
    if(pid=wait(&wstatus)<0) {
      ERRNO_FAT("wait", pid);
    } else if(wstatus)
      // non-fatal notice: child process died with non-zero exit code
      dprintf(2, "%s: wait: \"%d\": Process terminated with exit status %d\n",
              pid, wstatus);
  }

  check_dll(dll, stats->net_dll_len_chg, is_seqlock);

  dll_destroy(dll, slab);
  slab_destroy(slab);
}
int main(void) {
  dprintf(2, "=====\nslabtest.c\n"
             "=====\nTHREAD_CNT:\t%d\nSAMPLE_CNT:\t%d\n"
             "SAMPLE_MAX:\t%d\nNSLOTS:\t\t%d\n",
          THREAD_CNT, SAMPLE_CNT, SAMPLE_MAX, NSLOTS);

  // with spinlock
  generate_slab_test(0);

  // with seqlock
  generate_slab_test(1);
}
