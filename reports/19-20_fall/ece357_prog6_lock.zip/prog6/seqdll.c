#include "errfat.h"
#include "dll.h"
#include "slab.h"
#include "stats.h"

// This dll implementation uses seqlocking. See dll.h for more info.

// for optimistic seqlock read statistics; see seq_dll_find

struct dll *seq_dll_insert(struct dll *anchor, int value, struct slab *slab) {
  struct dll *new_node, *it;
  int seqlock_cnt;

  if(!(new_node = (struct dll *) slab_alloc(slab)))
    return NULL;
  new_node->value = value;

  write_seqlock(&anchor->seqlock);
  for(it=anchor->fwd; it->value<value&&it!=anchor&&it!=it->fwd; it=it->fwd);
  new_node->fwd = it;
  new_node->rev = it->rev;
  it->rev = it->rev->fwd = new_node;
  write_sequnlock(&anchor->seqlock);
  return new_node;
}

int seq_dll_delete(struct dll *anchor, struct dll *node, struct slab *slab) {
  write_seqlock(&anchor->seqlock);
  // this condition if multiple deletes on same dll in quick succession
  if(!node || node->fwd == node) {
    write_sequnlock(&anchor->seqlock);
    return -1;
  }
  node->rev->fwd = node->fwd;
  node->fwd->rev = node->rev;
  node->fwd = node->rev = node;
  write_sequnlock(&anchor->seqlock);

  if(slab_dealloc(slab, node)<0)
    ERR_FAT("slab_dealloc", "", "Deallocating node failed");
  return 1;
}

struct dll *seq_dll_find(struct dll *anchor, int value) {
  struct dll *it;
  int seqlock_cnt, cnt=0;

  do {
    seqlock_cnt = read_seqbegin(&anchor->seqlock);
    if(anchor->fwd==anchor || value<anchor->fwd->value
       || value>anchor->rev->value)
      return NULL;

    for(it=anchor->fwd; it->value<value&&it!=anchor&&it!=it->fwd; it=it->fwd);
  } while(++cnt, read_seqretry(&anchor->seqlock, seqlock_cnt));

  spin_lock(&stats->lock);
  stats->att_seqlock_read += cnt;
  stats->suc_seqlock_read++;
  spin_unlock(&stats->lock);
  return it->value==value && it!=anchor ? it : NULL;
}
