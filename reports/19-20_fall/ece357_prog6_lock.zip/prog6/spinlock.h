#ifndef __SPINLOCK_H
#define __SPINLOCK_H
// shadows linux's spinlock_t in /include/linux/spinlock_types.h
// but that's what we're imitating here anyways
typedef volatile char spinlock_t;
void spin_lock(spinlock_t *sl);
void spin_unlock(spinlock_t *sl);
#endif
