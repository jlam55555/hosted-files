% demodulates a signal modulated using the SSB AM scheme; currently
% assumes phase coherence (no pilot tone in modulated signal)
% params:
% sig_c = SSB AM-modulated signal
% f_c   = carrier frequency (Hz)
% A_c   = carrier amplitude
% f_s_m = baseband sampling frequency
% f_s_c = carrier sampling frequency (Hz)
% tau   = LPF cutoff frequency
% returns:
% sig_m = demodulated signal at baseband sampling frequency
function sig_m = ssb_demod(sig_c, f_c, A_c, f_s_m, f_s_c, tau)
    duration = length(sig_c) / f_s_c;
    t_c = linspace(0, duration, f_s_c * duration);
    t_m = linspace(0, duration, f_s_m * duration);
    
    % demodulate in-phase component
    sig_c = sig_c .* cos(2 * pi * f_c * t_c);
    
    % low-pass filtering in freq. domain; set cutoff frequency to carrier
    % frequency
    wd = linspace(-pi, pi, length(sig_c));
    f_c = wd * f_s_c / (2 * pi);
    lpf = (1 + f_c/tau*1j).^-1;             % LPF frequency response
    hpf = (1 - 20*f_c.^-1*1j).^-1;          % HPF to remove low frequency
                                            % distortion from pilot
    ft_c = fftshift(fft(sig_c)) / f_s_c;    % freq. domain rectified signal
    ft_c = lpf .* hpf .* ft_c;              % apply filter in freq. domain
    sig_c = ifft(ifftshift(ft_c) * f_s_c);
    
    % scale and downsample
    sig_m = real(interp1(t_c, sig_c, t_m));
    
    % scale back up to original amplitude
    sig_m = 2 * sig_m / A_c;
end