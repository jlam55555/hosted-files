% demodulates a signal modulated using the FM scheme
% params:
% sig_m = message signal
% A_c   = amplitude of carrier
% f_s_m = downsampled sampling rate
% f_s_c = updampled sampling rate
% k     = k_f, frequency deviation coefficient
% tau   = LPF cutoff frequency
% returns:
% sig_m = FM-demodulated signal at downsampled rate
function sig_m = fm_demod(sig_c, A_c, f_s_m, f_s_c, k, tau)
    % differentiate (same as multiplying by jw in freq domain)
    sig_c = [(diff(sig_c) * f_s_c) 0];
    
    % rectify signal
    sig_c(sig_c < 0) = 0;
    
    % lpf and hpf
    wd = linspace(-pi, pi, length(sig_c));
    f_c = wd * f_s_c / (2 * pi);
    hpf = (1 - 20*f_c.^-1*1j).^-1;          % HPF
    lpf = (1 + f_c/tau*1j).^-1;             % LPF frequency response
    ft_c = fftshift(fft(sig_c));            % freq. domain rectified signal
    
    % apply LPF multiple times in a row to completely get rid of carrier
    % frequency
    ft_c = lpf .^ 2 .* hpf .* ft_c;         % apply filter in freq. domain
    sig_c = ifft(ifftshift(ft_c));
    
    % factor of 3.4 found empirically (similar to conventional AM demod)
    sig_c = 3.4 * real(sig_c) / (2 * pi * k * A_c);
    
    % downsample sig_c
    duration = length(sig_c) / f_s_c;
    t_m = linspace(0, duration, f_s_m * duration);
    t_c = linspace(0, duration, length(sig_c));
    sig_m = interp1(t_c, sig_c, t_m);
end