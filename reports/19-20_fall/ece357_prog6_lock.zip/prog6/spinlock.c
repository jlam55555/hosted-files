#include "tas.h"
#include "spinlock.h"

void spin_lock(spinlock_t *sl) {
  while(tas(sl));
}
void spin_unlock(spinlock_t *sl) {
  *sl = 0;
}
