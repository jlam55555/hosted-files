%%
clc; close all; clear;
load('pj2data.mat');

set(0, 'defaultTextInterpreter', 'latex');

%%
figure('position', [0 0 600 400]);
tiledlayout(2, 1, 'TileSpacing', 'Compact');

nexttile();
plot(y);
title('$y$ signal');
xlabel('$n$');
ylabel('$y[n]$');
xlim([0 length(y)]);

nexttile();
w = linspace(0, 2*pi, length(Hejw2));
xt = 0:pi/2:2*pi;
xtl = ["0", "\pi/2", "\pi", "3\pi/2", "2\pi"];
plot(w, Hejw2);
title('True channel frequency response');
xlabel('$\omega$');
ylabel('$|H(e^{j\omega})|^2$');
xlim([0 2*pi]);
xticks(xt);
xticklabels(xtl);

exportgraphics(gcf(), 'y_hejw2.pdf');

%% A
y1 = y(1:32);
autocorr1 = xcorr(y1, y1, 'biased');
autocorr2 = conv(y1, flip(y1));

figure('position', [0 0 600 400]);
tiledlayout(2, 1, 'TileSpacing', 'Compact');

nexttile();
plot(autocorr1);
title('Cross-correlation of $y$ with itself');
xlabel('$n$');
ylabel('(xcorr($y$))[n]');
xlim([0 length(autocorr1)]);

nexttile();
plot(autocorr2);
title('Convolution of $y$ with flipped verion of itself');
xlabel('$n$');
ylabel('(conv($y$, flip($y$)))[n]');
xlim([0 length(autocorr2)]);

exportgraphics(gcf(), 'xcorr_vs_conv.pdf');

%% A.1
% See http://matlab.izmiran.ru/help/toolbox/signal/spectra3.html

%% A.2
% The Fourier transform of the autocorrelation is equal to the PSD, which 
% we know to be positive and real.

%% A.3
c_y1 = xcorr(y1, 'biased');
psd_y1 = fft(c_y1, 64);

N_y1 = length(y1);
phi_y1 = 2;

subplot(2, 1, 1);
plot(abs(psd_y1));
subplot(2, 1, 2);
plot(unwrap(angle(psd_y1)));

%%
phi_y1 = zeros(1, 32);
for i = 1:N_y1
    phi_y1(i) = sum(y1(1:N_y1-i+1) .* y1(i:N_y1)) / N_y1;
end
phi_y1 = [flip(phi_y1(2:end)) phi_y1];

figure('position', [0 0 600 600]);
tiledlayout(3, 1);

nexttile();
plot(phi_y1);
title('Autocorrelation');
xlabel('$\tau$');
ylabel('autocorr$_{y_1}(\tau)$');
xlim([0 64]);

nexttile();
w = linspace(0, 2*pi, 64);
plot(w, abs(fft(phi_y1, 64)));
title('FFT of autocorrelation estimate of PSD magnitude');
xlabel('$\omega$');
xlim([0 2*pi]);
xlabel('$\omega$');
xticks(0:pi/2:2*pi);
xticklabels(["0", "\pi/2", "\pi", "3\pi/2", "2\pi"]);
ylabel('fft(autocorr$_{y_1}(\omega))|$')

nexttile();
plot(w, unwrap(angle(fft(phi_y1, 64))));
title('FFT of autocorrelation estimate of PSD angle');
xlabel('$\omega$');
xlim([0 2*pi]);
xlabel('$\omega$');
xticks(0:pi/2:2*pi);
xticklabels(["0", "\pi/2", "\pi", "3\pi/2", "2\pi"]);
ylabel('arg(fft(autocorr$_{y_1}(\omega)))$');

exportgraphics(gcf(), 'det_autocorr.pdf');

%% A.3
fft_y1 = fft(y1, 64);
psd_y12 = abs(fft_y1) .^ 2;

fft_y = fft(y(1:64), 64);
psd_y = abs(fft_y) .^ 2;

figure('position', [0 0 600 400]);
w = linspace(0, 2*pi, 64);
hold on;
plot(w, abs(psd_y1));
plot(w, psd_y12/64);
plot(w, psd_y/64);
plot(w, Hejw2(1:8:512))
hold off;

title('Comparisons of PSD estimates');
xlim([0 2*pi]);
xlabel('$\omega$');
xticks(0:pi/2:2*pi);
xticklabels(["0", "\pi/2", "\pi", "3\pi/2", "2\pi"]);
xlabel('$\omega$');
ylabel('$\hat\Phi_{y}(\omega)$');
legend(["Method 1", "Method 2", "Method 3", "|H(e^{j\omega})|^2"]);
exportgraphics(gcf(), 'psd_est_comp.pdf');

%% B.1
figure('position', [0 0 600 400]);
tiledlayout(2, 1, 'TileSpacing', 'compact');

% already calculated in previous question
w = linspace(0, 2*pi, 64);
nexttile();
hold on;
plot(w, psd_y12/64);
plot(w, Hejw2(1:8:512));
hold off;
xlim([0 2*pi]);
xlabel('$\omega$');
xticks(0:pi/2:2*pi);
xticklabels(["0", "\pi/2", "\pi", "3\pi/2", "2\pi"]);
ylabel('$\hat\Phi_{y}(\omega)$');
title('PSD estimate using 32 samples, 64-point FFT');

err = sum((Hejw2(1:8:512) - psd_y12/64).^2) / 64

% B.2
fft_y = fft(y, 1024);

psd_y = abs(fft_y) .^ 2;

w = linspace(0, 2*pi, 1024);
nexttile();
hold on;
plot(w, psd_y / 1024);
w = linspace(0, 2*pi, 512);
plot(w, Hejw2);
hold off;
xlim([0 2*pi]);
xlabel('$\omega$');
xticks(0:pi/2:2*pi);
xticklabels(["0", "\pi/2", "\pi", "3\pi/2", "2\pi"]);
ylabel('$\hat\Phi_{y}(\omega)$');
title('PSD estimate using 512 samples, 1024-point FFT');

err = sum((Hejw2 - psd_y(1:2:1024)/1024).^2) / 512
exportgraphics(gcf(), 'b12.pdf');

%% B.3
N = length(y);
periodograms = zeros(N/32, 64);
for i = 0:(N/32-1)
    fft_y = fft(y((1+32*i):(32*(i+1))), 64);
    psd_y = abs(fft_y) .^ 2 / 64;
    periodograms(i+1, :) = psd_y;
end

psd_avg = mean(periodograms, 1);

figure('position', [0 0 600 400]);
hold on;
w = linspace(0, 2*pi, 64);
plot(w, psd_avg);
plot(w, Hejw2(1:8:512));
hold off;
xlim([0 2*pi]);
xlabel('$\omega$');
xticks(0:pi/2:2*pi);
xticklabels(["0", "\pi/2", "\pi", "3\pi/2", "2\pi"]);
ylabel('$\hat\Phi_{y}(\omega)$');
title('Averaging 64-point (32-sample) periodograms');

err = sum((Hejw2(1:8:512) - psd_avg).^2) / 64
exportgraphics(gcf(), 'averaging.pdf');

%% B.4
c_y = xcorr(y, y, 'unbiased');
c_y_trunc = c_y(512-15:512+15);

fft_autocorr = abs(fft(c_y_trunc, 64));

hold on;
w = linspace(0, 2*pi, 64);
plot(w, fft_autocorr);
plot(w, Hejw2(1:8:512));
hold off;
xlim([0 2*pi]);
xlabel('$\omega$');
xticks(0:pi/2:2*pi);
xticklabels(["0", "\pi/2", "\pi", "3\pi/2", "2\pi"]);
ylabel('$\hat\Phi_{y}(\omega)$');
title('Indirect Blackman-Tukey method w/ rectangular window');

err = sum((Hejw2(1:8:512) - fft_autocorr).^2) / 64
exportgraphics(gcf(), 'blackman_tukey.pdf');

%% B.5c
c_y_trunc_trian = triang(31).' .* c_y_trunc;
fft_autocorr_2 = abs(fft(c_y_trunc_trian, 64));

hold on;
w = linspace(0, 2*pi, 64);
plot(w, fft_autocorr_2);
plot(w, Hejw2(1:8:512));
hold off;
xlim([0 2*pi]);
xlabel('$\omega$');
xticks(0:pi/2:2*pi);
xticklabels(["0", "\pi/2", "\pi", "3\pi/2", "2\pi"]);
ylabel('$\hat\Phi_{y}(\omega)$');
title('Indirect Blackman-Tukey method w/ triangular window');

err = sum((Hejw2(1:8:512) - fft_autocorr_2).^2) / 64
exportgraphics(gcf(), 'blackman_tukey_triangular.pdf');