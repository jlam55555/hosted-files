close all; clear; clc;
set(0, 'defaultTextInterpreter', 'latex');

%% Project details
global pset_name;
pset_name = 'ece300_proj1';

% audio details
audio_filename = 'welcome.wav';
audio_samples = 20000;

%% Load audio

% loads y, Fs
[sig_m, f_s_m] = audioread(audio_filename);
sig_m = sig_m(1:audio_samples)';

% make maximum magnitude 1 to avoid problems with conventional AM
sig_m = sig_m / max(abs(sig_m));

% plot audio
figure('visible', 'off');
tiledlayout(1, 2, 'TileSpacing', 'Compact', 'Padding', 'Compact');

duration = length(sig_m) / f_s_m;
t_m = linspace(0, duration, length(sig_m));

nexttile();
plot(t_m, sig_m);
title('Original signal');
ylabel('$m(t)$');
xlabel('$t$');
xlim([0, duration]);
ylim([-1.2, 1.2]);

[f, ft] = plot_ft(sig_m, f_s_m);
nexttile();
semilogy(f, ft);
title('Magnitude of original signal Fourier transform');
ylabel('$|M(f)|$');
xlabel('$f$');
ylim([10e-8, 10e-2]);

fig_save('sig_m', [80 20]);

% get bandwidth
W = obw(sig_m, f_s_m);

% get signal power
P_m = bandpower(sig_m);

% write original signal to filesig_mod
audiowrite('original.wav', sig_m, f_s_m);

%% Modulation configuration

% conventional AM
a_conv = 0.5;
A_c_conv = 4;
f_c_conv = 500000;
f_s_c_conv = 2000000;

% SSB AM
f_c_ssb = 500000;
A_c_ssb = A_c_conv / sqrt(8);
f_s_c_ssb = 2000000;
is_ussb = false;

% PM
f_c_pm = 500000;
A_c_pm = A_c_conv;
f_s_c_pm = 5000000;
k_p = 0.1;

% FM
f_c_fm = 400000;
A_c_fm = A_c_conv;
f_s_c_fm = 5000000;
k_f = 10 * W;

% for when viewing the effect of varying noise std.
noise_stds = [0 0.1 0.5 1];

% for when viewing the effect of varying modulation index
noise_std_conv = 1;
noise_std_fm = 0.5;
noise_std_pm = 1;

% for storing the theoretical snrs
var_noise_theo = zeros(4,4);
var_noise_emp = zeros(4,4);
var_mod_ind_theo = zeros(3,3);
var_mod_ind_emp = zeros(3, 3);

%% conventional AM modulation
sig_conv_modded = conv_mod(f_c_conv, A_c_conv, a_conv, ...
    sig_m, f_s_m, f_s_c_conv);
sig_conv_demodded = conv_demod(sig_conv_modded, A_c_conv, ...
    a_conv, f_s_m, f_s_c_conv, W);
plot_modded_demodded(sig_conv_modded, sig_conv_demodded, ...
    f_s_m, f_s_c_conv, 'conv');
audiowrite('conv_demodded.wav', sig_conv_demodded, f_s_m);

%% SSB AM modulation
sig_ssb_modded = ssb_mod(f_c_ssb, A_c_ssb, sig_m, f_s_m, f_s_c_ssb, ...
    is_ussb);
sig_ssb_demodded = ssb_demod(sig_ssb_modded, f_c_ssb, A_c_ssb, ...
    f_s_m, f_s_c_ssb, W);
plot_modded_demodded(sig_ssb_modded, sig_ssb_demodded, f_s_m, ...
    f_s_c_ssb, 'ssb');
audiowrite('ssb_demodded.wav', sig_ssb_demodded, f_s_m);

%% PM Modulation
sig_pm_modded = pm_mod(f_c_pm, A_c_pm, sig_m, k_p, f_s_m, f_s_c_pm);
sig_pm_demodded = pm_demod(f_c_pm, A_c_pm, sig_pm_modded, k_p, ...
    f_s_m, f_s_c_pm, W);
plot_modded_demodded(sig_pm_modded, sig_pm_demodded, f_s_m, ...
    f_s_c_pm, 'pm');
audiowrite('sig_pm_demodded.wav', sig_pm_demodded, f_s_m);

%% FM Modulation
sig_fm_modded = fm_mod(f_c_fm, A_c_fm, sig_m, k_f, f_s_m, f_s_c_fm);
sig_fm_demodded = fm_demod(sig_fm_modded, A_c_fm, f_s_m, f_s_c_fm, ...
    k_f, W);
plot_modded_demodded(sig_fm_modded, sig_fm_demodded, f_s_m, ...
    f_s_c_fm, 'fm');
audiowrite('sig_fm_demodded.wav', sig_fm_demodded, f_s_m);

%% Conventional AM with noise
demod_fn = @(sig_mod) conv_demod(sig_mod, A_c_conv, a_conv, f_s_m, ...
    f_s_c_conv, W);
[sigs_conv_modded, sigs_conv_demodded, snrs] = apply_noise(noise_stds, ...
    demod_fn, sig_conv_modded, sig_conv_demodded, f_s_m, ...
    f_s_c_conv, W, 'conv');
var_noise_emp(1,:) = snrs;

%% calculate conventional AM theoretical SNR
var_noise_theo(1,:) = 10 * log10(a_conv^2 * A_c_conv^2 * ...
    bandpower(sig_m) * (2 * (2 * noise_stds.^2) * W / f_s_c_conv).^-1);

%% SSB AM with noise
demod_fn = @(sig_mod) ssb_demod(sig_mod, f_c_ssb, A_c_ssb, f_s_m, ...
    f_s_c_ssb, W);
[sigs_ssb_modded, sigs_ssb_demodded, snrs] = apply_noise(noise_stds, ...
    demod_fn, sig_ssb_modded, sig_ssb_demodded, f_s_m, f_s_c_ssb, ...
    W, 'ssb');
var_noise_emp(2,:) = snrs;

%% calculate SSB AM theoretical SNR
var_noise_theo(2,:) = 10 * log10(A_c_ssb^2 * bandpower(sig_m) * ...
    ((2 * noise_stds.^2) * W / f_s_c_ssb).^-1);

%% PM with noise
demod_fn = @(sig_mod) pm_demod(f_c_pm, A_c_pm, sig_mod, k_p, f_s_m, ...
    f_s_c_pm, W);
[sigs_pm_modded, sigs_pm_demodded, snrs] = apply_noise(noise_stds, ...
    demod_fn, sig_pm_modded, sig_pm_demodded, f_s_m, f_s_c_pm, W, 'pm');
var_noise_emp(3,:) = snrs;

%% calculate PM theoretical SNR
var_noise_theo(3,:) = 10 * log10(k_p^2 * A_c_pm^2 * bandpower(sig_m) * ...
    (2 * (2 * noise_stds.^2) * W / f_s_c_pm).^-1);

%% FM with noise
demod_fn = @(sig_mod) fm_demod(sig_mod, A_c_fm, f_s_m, f_s_c_fm, ...
    k_f, W);
[sigs_fm_modded, sigs_fm_demodded, snrs] = apply_noise(noise_stds, ...
    demod_fn, sig_fm_modded, sig_fm_demodded, f_s_m, f_s_c_fm, W, 'fm');
var_noise_emp(4,:) = snrs;

%% calculate FM theoretical SNR
beta_f = k_f / W;
var_noise_theo(4,:) = 10 * log10(3 * beta_f^2 * A_c_fm^2 * ...
    bandpower(sig_m) * (2 * (2 * noise_stds.^2) * W / f_s_c_fm).^-1);

%% Changing modulation index of Conventional AM
mod_fn = @(sig_m, a) conv_mod(f_c_conv, A_c_conv, a, sig_m, f_s_m, ...
    f_s_c_conv);
demod_fn = @(sig_mod, a) conv_demod(sig_mod, A_c_conv, a, f_s_m, ...
    f_s_c_conv, W);
var_mod_ind_emp(1,:) = apply_modulation_factor( ...
    a_conv, noise_std_conv, mod_fn, demod_fn, sig_m, ...
    sigs_conv_modded(4,:), sigs_conv_demodded(4,:), f_s_m, ...
    f_s_c_conv, W, sig_conv_demodded, 'a', 'conv');

%% calculate conventional AM theoretical SNR
var_mod_ind_theo(1,:) = 10 * log10([a_conv/2 a_conv a_conv*2].^2 * ...
    A_c_conv^2 * bandpower(sig_m) * ( 2 * (2 * noise_std_conv) * W / ...
    f_s_c_conv)^-1);

%% Changing the modulation index of PM
mod_fn = @(sig_m, k_p) pm_mod(f_c_pm, A_c_pm, sig_m, k_p, f_s_m, f_s_c_pm);
demod_fn = @(sig_mod, k_p) pm_demod(f_c_pm, A_c_pm, sig_mod, k_p, ...
    f_s_m, f_s_c_pm, W);
var_mod_ind_emp(2,:) = apply_modulation_factor( ...
    k_p, noise_std_pm, mod_fn, demod_fn, sig_m, sigs_pm_modded(4,:), ...
    sigs_pm_demodded(4,:), f_s_m, f_s_c_pm, W, sig_pm_demodded, ...
    'k_p', 'pm');

%% calculate PM theoretical SNR
var_mod_ind_theo(2,:) = 10 * log10([k_p/2 k_p k_p*2].^2 * A_c_pm^2 * ...
    bandpower(sig_m) * (2 * (2 * noise_std_pm^2) * W / f_s_c_pm).^-1);

%% Changing the modulation index of FM
mod_fn = @(sig_m, k_f) fm_mod(f_c_fm, A_c_fm, sig_m, k_f, ...
    f_s_m, f_s_c_fm);
demod_fn = @(sig_mod, k_f) fm_demod(sig_mod, A_c_fm, f_s_m, ...
    f_s_c_fm, k_f, W);
var_mod_ind_emp(3,:) = apply_modulation_factor( ...
    k_f, noise_std_fm, mod_fn, demod_fn, sig_m, sigs_fm_modded(3,:), ...
    sigs_fm_demodded(3,:), f_s_m, f_s_c_fm, W, sig_fm_demodded, ...
    'k_f', 'fm');

%% calculate FM theoretical SNR
beta_f = [k_f/2 k_f k_f*2] / W;
var_mod_ind_theo(3,:) = 10 * log10(3 * beta_f.^2 * A_c_fm^2 * ...
    bandpower(sig_m) * (2 * (2 * noise_std_fm.^2) * W / f_s_c_fm).^-1);

%% Print out results
fprintf('Theoretical SNRs from varying noise variance');
var_noise_theo(:,2:4)
fprintf('Empirical SNRs from varying noise variance');
var_noise_emp(:,2:4)
fprintf('Theoretical SNRs from varying modulation indices');
var_mod_ind_theo
fprintf('Empirical SNRs from varying modulation indices');
var_mod_ind_emp

% plot modulation modded and demodded signals and their FTs
% params:
% sig_modded    = modulated signal
% sig_demodded  = demodulated signal
% f_s_m         = baseband sampling frequency
% f_s_c         = modulated signal sampling frequency
% figname       = name of figure
function plot_modded_demodded(sig_modded, sig_demodded, f_s_m, f_s_c, ...
    figname)

    figure('visible', 'off');
    tiledlayout(2, 2, 'TileSpacing', 'Compact', 'Padding', 'Compact');
    
    duration = length(sig_modded) / f_s_c;
    t_c = linspace(0, duration, length(sig_modded));
    t_m = linspace(0, duration, length(sig_demodded));

    % plot modded signal in time domain
    nexttile();
    plot(t_c, sig_modded);
    title('Modulated signal');
    ylabel('$u(t)$');
    xlabel('$t$');
    xlim([0 duration]);
    
    % plot modded signal in frequency domain
    nexttile();
    [f, ft] = plot_ft(sig_modded, f_s_c);
    semilogy(f, ft);
    title('Modulated signal Fourier transform magnitude');
    ylabel('$|U(f)|$');
    xlabel('$f$');
    
    % plot demodded signal in time domain
    nexttile();
    plot(t_m, sig_demodded);
    title('Demodulated signal');
    ylabel('$r(t)$');
    xlabel('$t$');
    ylim([-1.2 1.2]); 
    xlim([0 duration]);
    
    % plot demodded signal in frequency domain
    nexttile();
    [f, ft] = plot_ft(sig_demodded, f_s_m);
    semilogy(f, ft);
    title('Demodulated signal Fourier transform magnitude');
    ylabel('$|R(f)|$');
    xlabel('$f$');
    ylim([10e-8, 10e-2]);
    
    fig_save(figname, [40 20]);
end

% apply noise to signals modulated with different modulation indices
% params:
% mod_index             = modulation index values
% noise_std             = standard deviation of noise to add
% mod_fn                = lambda to modulate a signal
% demod_fn              = lambda to demod a noisy modulated signal
% sig_m                 = message signal
% sig_modded            = reference modded signal
% sig_demodded          = reference demodded signal
% f_s_m                 = baseband sampling frequency
% f_s_c                 = modulated signal sampling frequency
% tau                   = post-demodulation LPF cutoff frequency
% sig_demodded_no_noise = reference no-noise demodulated signal
% variant               = name of modulation index
% mod_type              = modulation scheme
% returns:
% snrs                  = SNRs of noisy modulated signals
function snrs = apply_modulation_factor( ...
    mod_index, noise_std, mod_fn, demod_fn, sig_m, sig_modded, ...
    sig_demodded, f_s_m, f_s_c, tau, sig_demodded_no_noise, variant, ...
    mod_type)
    
    sigs_modded = zeros(3, length(sig_modded));
    sigs_demodded = zeros(3, length(sig_demodded));

    % half the modulation index
    sigs_modded(1,:) = mod_fn(sig_m, mod_index/2) + ...
        noise_std * randn(1, length(sig_modded));
    sigs_demodded(1,:) = lowpass_audible(demod_fn(sigs_modded(1,:), ...
        mod_index/2), f_s_m, tau);
    
    % original modulation index
    sigs_modded(2,:) = sig_modded;
    sigs_demodded(2,:) = sig_demodded;

    % double the modulation index
    sigs_modded(3,:) = mod_fn(sig_m, mod_index*2) + ...
        noise_std * randn(1, length(sig_modded));
    sigs_demodded(3,:) = lowpass_audible(demod_fn(sigs_modded(3,:), ...
        mod_index*2), f_s_m, tau);

    % plot
    snrs = plot_with_noise([mod_index/2, mod_index, mod_index*2], ...
        sigs_modded, sigs_demodded, f_s_m, f_s_c, ...
        sig_demodded_no_noise, variant, mod_type);
end

% apply different noise to a modded signal
% params:
% noise_stds            = list of standard deviations of the noise
% demod_fn              = lambda to demod a noisy signal
% sig_modded_no_noise   = no-noise modded signal reference
% sig_demodded_no_noise = no-noise demodded signal reference
% f_s_m                 = baseband sampling frequency
% f_s_c                 = modulated signal sampling frequency
% tau                   = cutoff frequency
% mod_type              = modulation scheme
% returns:
% sigs_modded           = modulated signals with applied noise
% sigs_demodded         = demodulated noisy modded signals
% snrs                  = snrs for demodded signals
function [sigs_modded, sigs_demodded, snrs] = apply_noise(noise_stds, ...
    demod_fn, sig_modded_no_noise, sig_demodded_no_noise, f_s_m, f_s_c, ...
    tau, mod_type)
    
    sigs_modded = zeros(length(noise_stds), ...
        length(sig_modded_no_noise));
    sigs_demodded = zeros(length(noise_stds), ...
        length(sig_demodded_no_noise));

    % first element will be the no-noise variant
    sigs_modded(1,:) = sig_modded_no_noise;
    sigs_demodded(1,:) = sig_demodded_no_noise;

    % loop through each noise process
    for i = 2:length(noise_stds)
        % modulate, add noise
        sigs_modded(i,:) = sig_modded_no_noise + ...
            noise_stds(i) * randn(1, length(sig_modded_no_noise));
        
        % demod
        sigs_demodded(i,:) = lowpass_audible(...
            demod_fn(sigs_modded(i,:)), f_s_m, tau);
    end

    % plot
    snrs = plot_with_noise(noise_stds, sigs_modded, sigs_demodded, ...
        f_s_m, f_s_c, sig_demodded_no_noise, '\sigma_n', mod_type);
end

% approximates SNR in dB, given the pristine demodded signal and a noisy
% variant; approximates noise as the difference between the two
% params:
% sig_no_noise  = demodded signal with no noise
% sig_noisy     = noisy signal to calculate the SNR of
% returns:
% res           = SNR (in dB)
function res = snr(sig_no_noise, sig_noisy)
    res = 10 * log10(bandpower(sig_no_noise) / ...
                     bandpower(sig_no_noise - sig_noisy));
end

% plots the demodded signal, spectrum of modded signal, and spectrum of
% demodded signal for a series of related signals with one varying
% variable; also calculates SNRs and returns them
% variant
% params:
% variants      = list of varying parameter values
% sigs_modded   = modded signals
% sigs_demodded = demodded signals
% f_s_m         = sample rate of baseband signal
% f_s_c         = sample rate of modulated signal
% sig_snr_ref   = reference for SNR calculation (i.e., no-noise demodded)
% variant       = name of varying parameter
% mod_type      = modulation type (e.g., CONV, FM)
% returns:
% snrs          = calculated SNRs of each demodded signal wrt. sig_snr_ref
function [snrs] = plot_with_noise(variants, sigs_modded, sigs_demodded, ...
    f_s_m, f_s_c, sig_snr_ref, variant, mod_type)

    N = length(variants);
    snrs = zeros(N, 1);
    
    figure('visible', 'off');
    tiledlayout(N, 3, 'TileSpacing', 'Compact', 'Padding', 'Compact');
    
    for i = 1:N
        
        % plot demodded signal
        nexttile();
        plot(sigs_demodded(i,:));
        ylim([-1.25, 1.25]);
        snr_db = snr(sig_snr_ref, sigs_demodded(i,:));
        snrs(i) = snr_db;
        title(sprintf('Demodded signal; $%s=%0.2f$, SNR=%0.2fdB', ...
            variant, variants(i), snr_db));
        ylabel('$m(t)$');
        xlabel('$t$');
        
        % plot spectrum of modded signal
        nexttile();
        [f, ft] = plot_ft(sigs_modded(i,:), f_s_c);
        semilogy(f, ft);
        title(sprintf('Spectrum of modded signal; $%s=%0.2f$', ...
            variant, variants(i)));
        ylabel('$|M_{mod}(f)|$');
        xlabel('$f$');
        
        % plot spectrum of demodded signal
        nexttile();
        [f, ft] = plot_ft(sigs_demodded(i,:), f_s_m);
        semilogy(f, ft);
        ylim([10e-10, 10e0]);
        title(sprintf('Spectrum of demodded signal; $%s=%0.2f$', ...
            variant, variants(i)));
        ylabel('$|M(f)|$');
        xlabel('$f$');
    end
    
    if strcmp(variant, '\sigma_n')
        variant = 'noise_std';
    end
    fig_save(sprintf('%s_var_%s', mod_type, variant), [60, 10 * N]);
end