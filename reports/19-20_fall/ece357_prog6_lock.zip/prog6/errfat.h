#ifndef __ERRFAT_H
#define __ERRFAT_H
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern char *PROG;
#define ERR_FAT(op, ctx, msg) {\
    dprintf(2, "%s: ERROR: %s (%s): %s\n", PROG, op, ctx, msg);\
    exit(EXIT_FAILURE);\
  }
#define ERRNO_FAT(op, ctx)\
  ERR_FAT(op, ctx, strerror(errno))
#endif
