% demodulates a signal modulated using the conventional AM scheme
% params:
% sig_c = conventional-AM modulated signal
% A_c   = carrier amplitude
% a     = modulation index
% f_s_c = carrier sampling rate (Hz)
% tau   = LPF cutoff (Hz)
% returns:
% sig_c = demodulated signal at lower frequency
function sig_m = conv_demod(sig_c, A_c, a, f_s_m, f_s_c, tau)
    % half-wave rectification
    sig_c(sig_c < 0) = 0;
    
    % low-pass filtering in freq. domain
    wd = linspace(-pi, pi, length(sig_c));
    f_c = wd * f_s_c / (2 * pi);
    lpf = (1 + f_c/tau*1j).^-1;             % LPF frequency response
    hpf = (1 - 20*f_c.^-1*1j).^-1;          % HPF to get rid of offset
                                            % and rectifier noise
    ft_c = fftshift(fft(sig_c)) / f_s_c;    % freq. domain rectified signal
    ft_c = lpf .^ 2 .* hpf .* ft_c;         % apply filter in freq. domain
    
    sig_c = ifft(ifftshift(ft_c) * f_s_c);
    
    % downsample
    duration = length(sig_c) / f_s_c;
    t_c = linspace(0, duration, f_s_c * duration);
    t_m = linspace(0, duration, f_s_m * duration);
    sig_m = real(interp1(t_c, sig_c, t_m));
    
    % DC block
    sig_m = sig_m - mean(sig_m);
    
    % scaling; the extra factor is empirically determined to account for
    % the power in the carrier lost when filtering
    sig_m = 3.3 * sig_m / A_c / a;
end