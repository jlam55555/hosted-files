% demodulates a signal modulated using the PM scheme
% params:
% f_c   = frequency of carrier
% A_c   = amplitude of carrier
% sig_c = PM-modulated signal
% k     = k_p, phase deviation coefficient
% f_s_m = downsampled sampling rate
% f_s_c = upsampled sampling rate
% tau   = LPF cutoff frequency
% returns:
% sig_m = demodulated signal at downsampled rate
function sig_m = pm_demod(f_c, A_c, sig_c, k, f_s_m, f_s_c, tau)
    duration = length(sig_c) / f_s_c;
    t_c = linspace(0, duration, f_s_c * duration);
    t_m = linspace(0, duration, f_s_m * duration);
    
    % mix with sine; negative because quadrature component is negative
    sig_c = -sig_c .* sin(2 * pi * f_c * t_c);
    
    % LPF and HPF
    wd = linspace(-pi, pi, length(sig_c));
    f_c = wd * f_s_c / (2 * pi);
    hpf = (1 - 20*f_c.^-1*1j).^-1;          % HPF
    lpf = (1 + f_c/tau*1j).^-1;             % LPF frequency response
    ft_c = fftshift(fft(sig_c));            % freq. domain rectified signal
    ft_c = lpf .^ 2 .* hpf .* ft_c;         % apply filter in freq. domain
    sig_c = ifft(ifftshift(ft_c));
    
    % downsample
    sig_m = real(interp1(t_c, sig_c, t_m) / (k * A_c));
    
    % restore amplitude
    sig_m = sig_m * 2;
end