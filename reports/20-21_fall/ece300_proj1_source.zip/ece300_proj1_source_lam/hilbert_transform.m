% hilbert transform of a signal; copied from earlier psets; for SSB AM
% params:
% sig_x = input signal
% returns:
% res   = hilbert transform of sig_x
function res = hilbert_transform(sig_x)
    ft_x = fft(sig_x);
    len_x = length(sig_x);
    
    % get signum of frequency; +1 for 0 to pi, -1 for -pi to 0
    sgn = [ones(1, floor(len_x/2)), -1*ones(1, ceil(len_x/2))];
    res = ifft(-1j * sgn .* ft_x);
end