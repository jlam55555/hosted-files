// Name: Jonathan Lam
// DSA Program 1: Lists, Stacks, and Queues
// Description: This program implements a singly-linked LinkedList (SimpleList), which is the parent class of Stack and Queue. The user is asked for an input and output file, and each of the commands are passed to parse_command() to break it into its components, which are sent to the correct version of a template function execute_command(), which executes the command, taking into account the list type.
// Note that C++11 std::stoi and std::stod are used, so must compile with --std=c++11 flag.

#include <iostream>
#include <fstream>
#include <string>
#include <list>

// implemented data structures
#include "simplelist.h"
#include "stack.h"
#include "queue.h"

// global lists of simplelists
std::list<SimpleList<int> *> list_simplelist_int;
std::list<SimpleList<double> *> list_simplelist_double;
std::list<SimpleList<std::string> *> list_simplelist_string;

// function declarations
void parse_command(std::string line, std::ofstream &output);
template <class T>
void execute_command(std::string command, std::string list_name, std::string data, std::list<SimpleList<T> *> &list_simplelist, T (*convert_to_type)(std::string), std::ofstream &output);

// helper functions (for data input from string); used to convert data before pushing
std::string stos(std::string data) { return data; }
int stoi(std::string data) { return std::stoi(data); } 
double stof(std::string data) { return std::stod(data); } 

// generic function to execute command given command parts from parse_command
template <class T>
void execute_command(std::string command, std::string list_name, std::string data, std::list<SimpleList<T> *> &list_simplelist, T (*convert_to_type)(std::string), std::ofstream &output) {
  // on create command, check to see if name is taken; if not, add to list
  if(command == "create") {
    typename std::list<SimpleList<T> *>::iterator simplelist_iterator;
    for(simplelist_iterator = list_simplelist.begin(); simplelist_iterator != list_simplelist.end(); simplelist_iterator++) {
      if(list_name == (*simplelist_iterator)->get_name()) {
        output << "ERROR: This name already exists!\n";
        return;
      }
    }
    if(data == "queue") {
      list_simplelist.push_front(new Queue<T>(list_name));
    } else {
      list_simplelist.push_front(new Stack<T>(list_name));
    }
  }
    
  // on push and pop commands, get list with given name and push/pop
  else {
    SimpleList<T> *selected_simplelist = NULL;

    // get selected_simplelist
    typename std::list<SimpleList<T> *>::iterator simplelist_iterator;
    for(simplelist_iterator = list_simplelist.begin(); simplelist_iterator != list_simplelist.end(); simplelist_iterator++) {
      if(list_name == (*simplelist_iterator)->get_name()) {
        selected_simplelist = *simplelist_iterator;
        break;
      }
    }
    if(selected_simplelist == NULL) {
      output << "ERROR: This name does not exist!\n";
      return;
    }

    // when pushing, convert string to correct type first
    if(command == "push") {
      selected_simplelist->push((*convert_to_type)(data));
    }
    
    // when popping, check if list is empty; if not, pop
    else {
      if(selected_simplelist->is_empty()) {
        output << "ERROR: This list is empty!\n";
      } else {
        output << "Value popped: " << selected_simplelist->pop() << '\n';
      }
    }
  }
}

// parse_command breaks down the command into chunks and sends it to appropriate check_function (generic)
void parse_command(std::string line, std::ofstream &output) {
  output << "PROCESSING COMMAND: " << line << '\n';

  // get command
  std::string command = line.substr(0, line.find_first_of(" "));

  // get list name
  std::string list_full_name = line.substr(command.length()+1, line.find_first_of(" ", command.length()+1)-command.length()-1);
  char list_type = list_full_name.at(0);
  std::string list_name = list_full_name.substr(1, list_full_name.length());

  // get data argument (third argument if applicable)
  std::string data = line.length() == command.length() + list_full_name.length() + 1 ?
    "" :
    line.substr(command.length()+list_full_name.length()+2, line.length());

  // convert to correct types, and send to correct generic version of execute_command
  switch(list_type) {
    case 'i':
      execute_command<int>(command, list_name, data, list_simplelist_int, &stoi, output);
      break;
    case 'd':
      execute_command<double>(command, list_name, data, list_simplelist_double, &stof, output);
      break;
    case 's':
      execute_command<std::string>(command, list_name, data, list_simplelist_string, &stos, output);
      break;
  }
}

int main() {
  // get filenames
  std::string input_file;
  std::string output_file;

  std::cout << "Enter an input file: ";
  std::cin >> input_file;
  std::cout << "Enter an output file: ";
  std::cin >> output_file;

  // read file line by line, send each command (line) to parse_command
  std::ifstream input_file_handle(input_file.c_str());
  std::ofstream output_file_handle(output_file.c_str());
  std::string line;
  while(getline(input_file_handle, line)) {
    parse_command(line, output_file_handle);
  }
  input_file_handle.close();
  output_file_handle.close();
  
}
