#include "graph.h"
#include <iostream>

/** GENERIC GRAPH METHODS **/
// load vertices, edge from ids and distance
void graph::addEdge(std::string v1Id, std::string v2Id, int distance) {
    vertex *v1, *v2;

    // make sure v1, v2 exist in graph; if not, add it
    v1 = getVertexInsertIfNecessary(v1Id);
    v2 = getVertexInsertIfNecessary(v2Id);

    v1->addEdge(v2, distance);
}

// get vertex given its string id
graph::vertex *graph::getVertex(std::string vId) const {
    return static_cast<vertex *>(vertexMap.getPointer(vId));
}

// get vertex given its string id. If it doesn't exist in the graph, add it
// (his is useful when loading the graph)
graph::vertex *graph::getVertexInsertIfNecessary(std::string vId) {
    vertex *vPointer;

    if(vertexMap.contains(vId))
        return getVertex(vId);

    vertexList.push_back(vertex{vId});
    vPointer = &vertexList.back();
    vertexMap.insert(vId, vPointer);
    return vPointer;
}

/** GENERIC VERTEX METHODS **/
// load edge into adjacency list
void graph::vertex::addEdge(vertex *vTo, int distance) {
    adjList.push_back(edge{vTo, distance});
}

/** DIJKSTRA'S ALGORITHM METHODS **/
// set start vertex of graph for dijkstra's algorithm
int graph::setStartVertex(std::string vStartId) {
    if(!vertexMap.contains(vStartId))
        return 1;

    vStart = getVertex(vStartId);
    //vertexHeap.setKey(vStartId, 0);
    return 0;
}

// dijkstra's algorithm
void graph::dijkstra() {
    int vDistance;
    vertex *vCurrent;

    if (vStart == nullptr) {
        std::cerr << "ERROR: start vertex invalid" << std::endl;
        return;
    }

    // build heap (just linearly inserts)
    heap vertexHeap{static_cast<int>(vertexList.size())};
    for(vertex &v : vertexList)
      vertexHeap.insert(v.getLabel(), static_cast<int>(INFINITY), &v);
    vertexHeap.setKey(vStart->getLabel(), 0);

    // dijkstra's algorithm
    while(!vertexHeap.deleteMin(nullptr, &vDistance, &vCurrent)
           && vDistance != static_cast<int>(INFINITY))
        vCurrent->dijkstraNode(vertexHeap, vDistance);
}

// process the node with the current least distance (dijkstra's algorithm)
void graph::vertex::dijkstraNode(heap &vertexHeap, int vDistance) {
    int wDistance, wNewDistance;

    distance = vDistance;
    isKnown = true;
    for(edge vwEdge : adjList) {
        if(vwEdge.vTo->getIsKnown()) continue;

        vertexHeap.getKey(vwEdge.vTo->getLabel(), &wDistance);
        wNewDistance = vDistance + vwEdge.distance;

        if(wNewDistance < wDistance) {
            vertexHeap.setKey(vwEdge.vTo->getLabel(), wNewDistance);
            vwEdge.vTo->setVPrev(this);
        }
    }
}

/** WRITING OUTPUT TO FILE (TOSTRING) **/
std::string graph::vertex::toString() const {
    std::string res, path;
    vertex *vPath = const_cast<vertex *>(this);

    res = label + ": ";

    if(distance == static_cast<int>(INFINITY))
        return res + "NO PATH";

    res += std::to_string(distance) + " [";
    path = label;
    while((vPath = vPath->getVPrev()) != nullptr)
        path = vPath->getLabel() + ", " + path;
    return res + path + "]";
}

std::string graph::toString() const {
    std::string res = "";

    for(vertex v : vertexList)
        res += v.toString() + '\n';
    return res;
}
