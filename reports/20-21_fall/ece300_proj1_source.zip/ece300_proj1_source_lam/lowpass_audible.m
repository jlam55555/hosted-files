% lowpass: set tau to upper range of audible range
function sig_c = lowpass_audible(sig, f_s, tau)
    wd = linspace(-pi, pi, length(sig));
    f = wd * f_s / (2 * pi);
    ft = fftshift(fft(sig));
    
    % first-order LPF with cutoff frequency at tau
    lpf = (1 + f/tau*1j).^-1;
    ft = lpf .* ft;
    
    sig_c = real(ifft(ifftshift(ft)));
end