#ifndef __TAS_H
int tas(volatile char *lock);
#define __TAS_H
#endif
