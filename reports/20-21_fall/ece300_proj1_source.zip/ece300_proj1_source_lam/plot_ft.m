% helper function to plot the fourier transform of a signal
% params:
% x     = signal
% f_s   = sampling rate
% returns:
% f     = frequency axis
% ft    = fourier transform
function [f, ft] = plot_ft(sig, f_s)
    wd = linspace(-pi, pi, length(sig));
    f = wd * f_s / (2 * pi);
    ft = abs(fftshift(fft(sig)) / f_s);
end