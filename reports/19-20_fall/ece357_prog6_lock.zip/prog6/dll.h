#ifndef __DLL_H
#define __DLL_H
#include "spinlock.h"
#include "seqlock.h"

/**
  * This implementation of a sorted integer-valued circular doubly-linked list
  * doesn't do much error checking, assumes correct inputs. It also assumes
  * that all nodes in a struct dll are allocated from the same struct slab
  * as its anchor. Both spinlock- and seqlock-protected versions are described
  * in this header file. A reasonable space optimization would be to store
  * the lock in the value field of the anchor, but this simple implementation
  * doesn't worry about saving space for clarity/simplicity of the lock.
  */

struct slab; // forward declaration b/c of circ. dep. -- see below
struct dll {
  int value;
  struct dll *fwd, *rev;

  // locks only used on anchor(s); see note above about saving space
  spinlock_t sl;          // for use with dll.c
  struct seqlock seqlock; // for use with dll2.c
};

#include "slab.h" // needs to be placed here b/c of circ. dep. b/t dll, slab

/**
  * Allocates and returns a DLL anchor. Not thread-safe (called from parent).
  * @param slab     slab to allocate from
  * @return         anchor node for DLL
  */
struct dll *dll_create(struct slab *slab);

/**
  * De-allocates all nodes in the DLL. Not thread-safe (called from parent).
  * @param anchor   anchor node for DLL
  * @param slab     slab where nodes are allocated
  */
void dll_destroy(struct dll *anchor, struct slab *slab);

/**
  * Insert an integer into the DLL. Thread-safe.
  * @param anchor   DLL anchor
  * @param value    integer value to add to DLL
  * @param slab     slab to allocate nodes from
  * @return         created node, or NULL on failure
  */
struct dll *spin_dll_insert(struct dll *anchor,int value,struct slab *slab);

/**
  * Delete a node from the DLL. Thread-safe.
  * @param anchor   DLL anchor
  * @param node     pointer to node to delete
  * @param slab     slab that node is allocated in
  * @return         1 on success, -1 on failure
  */
int spin_dll_delete(struct dll *anchor, struct dll *node,struct slab *slab);

/**
  * Find the first node with a given value in the DLL. Thread-safe.
  * @param anchor   DLL anchor
  * @param value    integer value to search for
  * @return         pointer to first node in DLL containing value, or NULL
  */
struct dll *spin_dll_find(struct dll *anchor,int value);

/**
  * Analogous functions protected using seqlock (extra credit). The insert
  * and delete functions are protected with write seqlocks, and the find is
  * protected with an optimistic read seqlock. Thread-safe. Keeps track of
  * statistics in stats (see stats.h);
  */
struct dll *seq_dll_insert(struct dll *anchor, int value, struct slab *slab);
int seq_dll_delete(struct dll *anchor, struct dll *node, struct slab *slab);
struct dll *seq_dll_find(struct dll *anchor, int value);

void print_dll(struct dll *anchor); // for debugging
#endif
