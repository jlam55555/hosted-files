#include "errfat.h"
#include "dll.h"
#include "slab.h"

// This dll implementation uses spinlocking. See dll.h for more info.

struct dll *dll_create(struct slab *slab) {
  struct dll *anchor;
  if(!(anchor = (struct dll *) slab_alloc(slab)))
    return NULL;
  anchor->fwd = anchor->rev = anchor;
  return anchor;
}
void dll_destroy(struct dll *anchor, struct slab *slab) {
  // it_fwd to avoid accessing it->nxt after it has been deallocated (and
  // possibly already reallocated)
  struct dll *it, *it_fwd;
  it = anchor, it_fwd = it->fwd;
  do {
    it_fwd = it->fwd;
    slab_dealloc(slab, it);
  } while((it=it_fwd) != anchor);
}

struct dll *spin_dll_insert(struct dll *anchor, int value, struct slab *slab) {
  struct dll *new_node, *it;

  if(!(new_node = (struct dll *) slab_alloc(slab)))
    return NULL;
  new_node->value = value;

  spin_lock(&anchor->sl);
  for(it=anchor->fwd; it->value<value && it!=anchor; it=it->fwd);
  new_node->fwd = it;
  new_node->rev = it->rev;
  it->rev = it->rev->fwd = new_node;
  spin_unlock(&anchor->sl);
  return new_node;
}

int spin_dll_delete(struct dll *anchor, struct dll *node, struct slab *slab) {
  spin_lock(&anchor->sl);
  // this condition if multiple deletes on same dll in quick succession
  if(!node || node->fwd==node) {
    spin_unlock(&anchor->sl);
    return -1;
  }
  node->rev->fwd = node->fwd;
  node->fwd->rev = node->rev;
  node->fwd = node->rev = node;
  spin_unlock(&anchor->sl);

  if(slab_dealloc(slab, node)<0)
    ERR_FAT("slab_dealloc", "", "Deallocating node failed");
  return 1;
}

struct dll *spin_dll_find(struct dll *anchor, int value) {
  struct dll *it;

  spin_lock(&anchor->sl);
  // some preliminary checks/optimizations
  if(anchor->fwd==anchor || value<anchor->fwd->value
     || value>anchor->rev->value) {
    spin_unlock(&anchor->sl);
    return NULL;
  }

  for(it=anchor->fwd; it->value<value && it!=anchor; it=it->fwd);
  spin_unlock(&anchor->sl);
  return it->value==value && it!=anchor ? it : NULL;
}

// for debugging
void print_dll(struct dll *anchor) {
  struct dll *it;

  spin_lock(&anchor->sl);
  dprintf(1, "printing dll: ");
  for(it = anchor->fwd; it != anchor; it=it->fwd)
    dprintf(1, "%d ", it->value);
  dprintf(1, "\n");
  spin_unlock(&anchor->sl);
}
