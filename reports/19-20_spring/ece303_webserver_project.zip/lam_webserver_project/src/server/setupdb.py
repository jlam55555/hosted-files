# https://docs.python.org/3/library/sqlite3.html
import sqlite3
conn = sqlite3.connect('messages.db')

c = conn.cursor()
c.execute('CREATE TABLE msg (date DATE, sender VARCHAR(64), receiver VARCHAR(64), message TEXT)')
conn.commit()
conn.close()
