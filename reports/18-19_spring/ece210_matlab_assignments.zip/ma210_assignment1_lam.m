% MA210 Assignment 1 -- Jonathan Lam
clc;clear all;close all

% 1.
scalar1 = log(9);
scalar2 = asin(exp(-9)) * 1e4;
scalar3 = log10(2 * pi / 9);
scalar4 = 9 + 1j;
scalarColumn = [scalar1; scalar2; scalar3; scalar4];

% 2.
complexReal = real(scalar4);
complexImaginary = imag(scalar4);
complexMagnitude = abs(scalar4);
complexPhase = angle(scalar4);
complexPropertyRow = [complexReal, complexImaginary, complexMagnitude, complexPhase];

% 3.
scalarColumnTimesComplexRow = scalarColumn * complexPropertyRow;
complexRowTimesScalarColumn = complexPropertyRow * scalarColumn;

% 4.
complexPropertyColumn = transpose(complexPropertyRow);
columnElementByElementProduct = complexPropertyColumn .* scalarColumn;
repeatedColumnProduct = repmat(columnElementByElementProduct, 1, 4);

% 5.
matrixProduct = scalarColumnTimesComplexRow * repeatedColumnProduct;
matrixElementByElementProduct = scalarColumnTimesComplexRow .* repeatedColumnProduct;
matrixTranspose = repeatedColumnProduct';
matrixSumInverse = (repeatedColumnProduct + eye(4))^-1;
matrixSquare = repeatedColumnProduct^2;

% 6.
n = fix(real(complexRowTimesScalarColumn));
linspaceInterval = linspace(1, n, 1000);
colonSyntaxInterval = 1:0.1:n;