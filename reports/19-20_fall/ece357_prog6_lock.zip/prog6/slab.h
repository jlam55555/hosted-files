#ifndef __SLAB_H
#define __SLAB_H
#include "spinlock.h"
#include "dll.h"

/**
  * Simple slab implementation. For simplicity, the slab is fixed-size, 
  * may only slab-allocate struct dlls, and the freemap is a slot. Slab ops
  * are protected with a simple spinlock.
  */

// NSLOTS should be small enough to fill up
#define NSLOTS 1000

struct slab {
  char freemap[NSLOTS];
  struct dll slots[NSLOTS];
  spinlock_t sl;

  // for optimization purposes on insert -- see slab_alloc for details
  int pos;
};

/** 
  * Allocate memory for slab. Not thread-safe.
  * @return         pointer to newly-allocated slab
  */
struct slab *slab_create();

/**
  * Unallocate slab. Not thread-safe.
  * @param          pointer to slab to de-allocate
  */
void slab_destroy(struct slab *slab);

/**
  * Allocate object in slab. Thread-safe.
  * @param slab     pointer to slab
  * @return         pointer to newly-allocated object, or NULL if slab is full
  */
void *slab_alloc(struct slab *slab);

/**
  * Deallocate object in slab. Thread-safe.
  * @param slab     pointer to slab
  * @param object   pointer to object to deallocate
  * @return         1 on success, -1 on failure
  */
int slab_dealloc(struct slab *slab, void *object);

// Allocate stats struct. Lumped in here to keep all mmap-ing in this file.
void stats_alloc();
#endif
