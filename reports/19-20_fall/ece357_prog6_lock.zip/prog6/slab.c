#include <sys/mman.h>
#include "errfat.h"
#include "slab.h"
#include "stats.h"

// See slab.h for more details.

struct slab *slab_create() {
  struct slab *slab; 
  if((slab = (struct slab *)
        mmap(NULL, sizeof(struct slab),PROT_READ|PROT_WRITE,
             MAP_SHARED|MAP_ANONYMOUS, -1, 0)) == MAP_FAILED)
    ERRNO_FAT("mmap", "slab_create");
  slab->pos = 0;
  return slab;
}
void slab_destroy(struct slab *slab) {
  if(munmap(slab, sizeof(struct slab)) < 0)
    ERRNO_FAT("munmap", "slab_destroy");
}

// to increase performance, allocation searches for a free slot beginning
// from where it last left off (as opposed to searching from start every time)
// i.e., slab->pos
void *slab_alloc(struct slab *slab) {
  unsigned int pos_start;
  void *res_pos;

  spin_lock(&slab->sl);
  for(pos_start=slab->pos?slab->pos-1:NSLOTS-1;
      slab->freemap[slab->pos] && slab->pos!=pos_start;
      slab->pos=(slab->pos+1)%NSLOTS);
  if(slab->pos==pos_start) {
    spin_unlock(&slab->sl);
    return NULL;
  }
  slab->freemap[slab->pos] = 1;
  res_pos = slab->slots+slab->pos;
  spin_unlock(&slab->sl);
  return res_pos;
}
int slab_dealloc(struct slab *slab, void *object) {
  int pos;

  spin_lock(&slab->sl);
  pos = ((struct dll *)object) - slab->slots;
  if(pos>=NSLOTS || !slab->freemap[pos]) {
    spin_unlock(&slab->sl);
    return -1;
  }
  slab->freemap[pos] = 0;
  spin_unlock(&slab->sl);
  return 1;
}

// see slab.h for details
void stats_alloc() {
  if((stats = (struct stats *)
        mmap(NULL, sizeof(struct stats),PROT_READ|PROT_WRITE,
             MAP_SHARED|MAP_ANONYMOUS, -1, 0)) == MAP_FAILED)
    ERRNO_FAT("mmap", "struct stat");
}
