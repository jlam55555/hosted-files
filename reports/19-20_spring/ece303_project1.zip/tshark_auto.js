const {exec, execSync} = require('child_process');

// get pcap filename
if(process.argv.length < 3)
  return console.error('usage: node tshark_auto [input_pcap_filename]');
const cmd = `tshark -r ${process.argv[2]} -Y tls.handshake.type==1 ` +
  `-Tjson -e ip.src -e ip.dst -e tls.handshake.extensions_server_name`;

// run tshark command
exec(cmd, (err, sout, serr) => {
  if(err)
    return console.error(`error running tshark: ${err}`);
  if(serr)
    return console.error(`tshark stderr: ${serr}`);

  parse(JSON.parse(sout));
});

// parse tshark output
const parse = tshark_out => {
  const entries = tshark_out.map(entry => entry._source.layers)
    .map(e => ({
      ip_src: e['ip.src'][0],
      ip_dst: e['ip.dst'][0],
      server_name: e['tls.handshake.extensions_server_name'][0]
    }));

  let completedCount = 0;
  entries.forEach(entry => {
    const ip = entry.ip_dst;
    let sout;
    // run this synchronously to avoid "Network unreachable" w/ whois protocol
    try {
      sout = execSync(`whois ${ip}`);
    } catch(e) {
      console.error(`error: "whois ${ip}" exited with status ${e.status}`);
    }

    entry['organization'] = (/\nOrganization:\s+([^\n]+)\n/
                              .exec(sout)||[0,''])[1].replace(', ', ' ');
    if(++completedCount == entries.length)
      finish_parsing(entries);
  });
};

// remove duplicates and print to stdout
const finish_parsing = entries => {
  console.log(`Source IP\tDestination IP\tServer Name\tOrganization`);
  entries
    .filter((e1, i) => i==entries.findIndex(e2 =>
      e1.ip_src==e2.ip_src && e1.ip_dst==e2.ip_dst && 
      e1.server_name==e2.server_name && e1.organization==e2.organization
    ))
    .forEach(e => {
      console.log(`${e.ip_src}\t${e.ip_dst}\t${e.server_name}\t${e.organization}`);
    });
};
