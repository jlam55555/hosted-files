#include "simplelist.h"

// Queue template: push inserts at end, pop removes from start
template <class T>
class Queue:public SimpleList<T> {
  public:
    Queue(std::string name);
    void push(T element);
    T pop();
};

template <class T>
Queue<T>::Queue(std::string name)
  : SimpleList<T>(name) { }

template <class T>
void Queue<T>::push(T element) {
  this->insert_at_end(element);
}

template <class T>
T Queue<T>::pop() {
  return this->remove_from_start();
}
