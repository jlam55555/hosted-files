% MA210 Assignment 3 -- Jonathan Lam
clc;clear all;close all;

% Q1
A = true([100 100]);
B = false([100 100]);

[i j] = meshgrid(1:100, 1:100);

A = ~(((i - 50) .^ 2 + (j - 50) .^ 2) .^ 0.5 < 20);
B = ((i - 40) .^ 2 + (j - 40) .^ 2) .^ 0.5 < 20;

figure('Name', 'A');
imshow(A);
% white bg w/ black circle w/ r=20 centered @ (50, 50)

figure('Name', 'B');
imshow(B);
% black bg w/ white circle w/ r=20 centered @ (40, 40)

figure('Name', 'A & B');
imshow(A & B);
% white crescent moon centered @ (40, 40)

figure('Name', 'A | B');
imshow(A | B);
% black crescent moon centered @ (50, 50)

figure('Name', '~(A & B)');
imshow(~(A & B));
% black crescent moon centered @ (40, 40)

figure('Name', '~(A | B)');
imshow(~(A | B));
% white crescent moon centered @ (50, 50)

% Q2
% fn at end of file
[closestValue, closestIndex] = findClosest(sin(linspace(0, 5, 100)) + 1, 3/2);

% Q3
% fn at end of file
sincDomain = linspace(-2*pi, 2*pi, 10001);

figure('Name', 'y = sinc(x)');
plot(sincDomain, sinc(sincDomain));

% *trecherous*^FF
% (expanded form can be found below)
signChanges = @(x) find(sign(x(2:end)) ~= sign(x(1:end-1)));

rootIndices = signChanges(sinc(sincDomain));
hold on;
plot(sincDomain(rootIndices), sinc(sincDomain(rootIndices)), 'ko');

% approximate derivative calculated as difference quotients over same
% interval as above
sincPrime = diff(sinc(sincDomain)) ./ diff(sincDomain);
extremaIndices = signChanges(sincPrime);
hold on;
plot(sincDomain(extremaIndices), sinc(sincDomain(extremaIndices)), 'r*');

% function for Q2: finds element (or elements if multiple at minimum
% difference) closest to desiredValue
function [val, ind] = findClosest(x, desiredValue)
    smallestDifference = min(abs(x(:) - desiredValue));
    ind = find(abs(x - desiredValue) == smallestDifference);
    val = x(ind);
end

% function for Q3: detect sign changes
% expanded version
function ind = signChangesExpanded(x)
    xShiftedLeft = sign(x(1:end-1));
    x = sign(x(2:end));
    ind = find(x ~= xShiftedLeft) + 1;
end