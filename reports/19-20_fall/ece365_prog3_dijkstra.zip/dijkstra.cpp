#include <ctime>
#include <fstream>
#include <iostream>
#include <string>
#include "graph.h"

int main() {
    std::clock_t startTime;
    std::ifstream graphFile;
    std::string graphFilename, outputFilename, v1Id, v2Id, vStartId;
    int edgeDistance;
    graph graph{};

    // read in graph
    std::cout << "Enter file name: ";
    std::cin >> graphFilename;
    graphFile = std::ifstream{graphFilename};

    while(graphFile >> v1Id, graphFile >> v2Id, graphFile >> edgeDistance)
        graph.addEdge(v1Id, v2Id, edgeDistance);

    // choose starting vertex
    do {
        std::cout << "Enter the starting node: ";
        std::cin >> vStartId;
    } while(graph.setStartVertex(vStartId));

    // run dijkstra's algorithm
    startTime = clock();
    graph.dijkstra();
    std::cout << "Dijkstra algorithm running time: "
              << double(clock() - startTime) / CLOCKS_PER_SEC
              << "s" << std::endl;

    // write to output file
    std::cout << "Enter output name: ";
    std::cin >> outputFilename;
    std::ofstream{outputFilename} << graph;
}
