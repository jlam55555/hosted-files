#include "hash.h"

// insert specified key into the hash table
int hashTable::insert(const std::string &key, void *pv) {
    int pos;

    // return 1 if key exists
    if(contains(key))
        return 1;

    // check if rehash needed; if it is and error, return 2
    // for now, if half full, rehash
    if(capacity / (filled + 1) < 2)
        if(!rehash())
            return 2;

    // insert item using linear probing
    // see findPos for explanation of probing
    for(pos = hash(key);
        data[pos].isOccupied && !data[pos].isDeleted;
        pos = (pos + 1) % capacity);
    data[pos] = hashItem{key, pv};
    filled++;
    return 0;
}

// returns whether or not key is found
bool hashTable::contains(const std::string &key) const {
    return findPos(key) != -1;
}

// get pointer associated with specified key
// uses findPos instead of contains to avoid searching twice
void *hashTable::getPointer(const std::string &key, bool *b) const {
    int pos = findPos(key);

    if(b != nullptr)
        *b = pos != -1;
    return pos != -1 ? data[pos].pv : nullptr;
}

// set pointer associated with specified key
// uses findPos instead of contains to avoid searching twice
int hashTable::setPointer(const std::string &key, void *pv) {
    int pos = findPos(key);

    if(pos == -1)
        return 0;
    data[pos].pv = pv;
    return 1;
}

// delete item with key
// uses findPos instead of contains to avoid searching twice
bool hashTable::remove(const std::string &key) {
    int pos = findPos(key);

    if(pos == -1)
        return false;
    data[pos].isDeleted = true;
    filled--;
    return true;
}

// uses simple hash fn from textbook (p. 198)
int hashTable::hash(const std::string &key) const {
    unsigned int hashVal = 0;

    for(char c : key)
        hashVal = 37 * hashVal + c;
    return hashVal % capacity;
}

// uses basic linear probing
int hashTable::findPos(const std::string &key) const {
    int pos;

    // linear probing continues:
    // - if cell is occupied
    // - if cell is deleted
    // - until key matches
    for(pos = hash(key);
        data[pos].isOccupied && (data[pos].key != key || data[pos].isDeleted);
        pos = (pos + 1) % capacity);

    return data[pos].isOccupied && data[pos].key == key && !data[pos].isDeleted
        ? pos : -1;
}

// rehash; for linear probing, rehash (roughly) doubles previous capacity
bool hashTable::rehash() {
    // don't set capacity to new capacity until memory allocation success
    long int newCapacity = getPrime(capacity * 2);
    std::vector<hashItem> newData{};

    try {
        newData.resize(newCapacity);
    } catch(std::bad_alloc) {
        return false;
    }

    // to allow use of insert on the new array, swap  data, newData
    // this is fast because it uses two moves internally (i.e., pointer swaps)
    // and clean becauses it reuses the insert function
    capacity = newCapacity;
    data.swap(newData);
    filled = 0;
    for(hashItem item : newData)
        if(item.isOccupied && !item.isDeleted)
            insert(item.key, item.pv);
    return true;
}

// get next prime larger than size; start at average size of ~25000 primes
const int primes[] = {24593, 49157, 98317, 196613, 393241, 786433, 1572869,
                      3145739, 6291469, 12582917};
unsigned int hashTable::getPrime(int size) {
    int i;
    for(i = 0; primes[i] < size && i < 10; i++);
    return primes[i];
}
