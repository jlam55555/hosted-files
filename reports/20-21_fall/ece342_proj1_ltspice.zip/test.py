import math

# thermal voltage
v_t = 26e-3

# from circuit
r_e = 3e3

# starting values for iteration
i_c = 1e-3
v_be = 0.7

# values from the ltspice 2n2222 model (IS, BF)
i_s = 1e-14
beta = 200

v_x = 50/(50+100)*15

def iterate():
	global i_c, v_be
	print(f'i_c: {i_c} v_be: {v_be}')
	v_be = v_t*math.log(i_c/i_s)
	i_c = (v_x-v_be)/r_e * beta/(beta+1)

for i in range(5):
	iterate()

print(f'i_b: {i_c/beta}')

v_y = 15 - i_c * 5e3
print(f'v_b2: {v_y}')

r_e2 = 2e3

i_s2 = 1e-14
beta2 = 250

i_c2 = 1e-3
v_eb = 0.7

v_cc = 15

def iterate2():
	global i_c2, v_eb
	print(f'i_c2: {i_c2} v_eb: {v_eb}')
	v_eb = v_t*math.log(i_c2/i_s2)
	i_c2 = (v_cc - (v_y + v_eb))/r_e2 * beta/(beta+1)

for i in range(5):
	iterate2()

print(f'i_b2: {i_c2/beta2}')

g_m1 = i_c/v_t
r_pi1 = beta/g_m1
g_m2 = i_c2/v_t
r_pi2 = beta2/g_m2
print(f'g_m1: {g_m1}\nr_pi1: {r_pi1}\ng_m2: {g_m2}\nr_pi2: {r_pi2}')

r_in2 = r_pi2+(beta2+1)*r_e2
r_c1 = 5e3
r_e1 = 3e3
r_c2 = 2.7e3
r_e2 = 2e3
print(f'A_v: = {5e3*r_in2/(5e3+r_in2)/(1/g_m1+r_e1)*r_c2/(1/g_m2+r_e2)}')
