% MA210 Assignment 2 -- Jonathan Lam
clc;clear all;close all;

% 1a
x = linspace(0,1,100);
y = exp(x);

% 1b
diffs = diff(x);
trapIntegral = trapz(y) * diffs(1);
rectIntegral = sum(y) * diffs(1);

% 1c
cumTrapIntegral = cumtrapz(y(1:99)) .* diff(x);
cumRectIntegral = cumsum(y(1:99)) .* diff(x);

% 1d
firstDerivative = diff(y) ./ diff(x);
secondDerivative = diff(firstDerivative) ./ diff(x(1:99));
lenFirstDerivative = size(firstDerivative);
lenSecondDerivative = size(secondDerivative);

% 1e
shiftedVector = circshift([0 1 2 3 4 5], 3);

% 2a
A = reshape(1:100, [10, 10]);

% 2b (only populates C with main diagonal values of B, 0 elsewhere)
B = magic(10);
C = diag(diag(B));

% 2c
B(:,2) = flipud(B(:,2));

% 2d
A = fliplr(A);

% 2e
cSum = sum(A*B);

% 2f
cMean = mean(A*B, 2);

% 2g
A(:,end) = [];

% 3a
tic
for i = 1:300
    for j = 1:500
        a1(i, j) = (i^2 + j^2) / (i + j + 3);
    end
end
threeAElapsed = toc;

% 3b
tic
a2 = zeros([300 500]);
for i = 1:300
    for j = 1:500
        a2(i, j) = (i^2 + j^2) / (i + j + 3);
    end
end
threeBElapsed = toc;

% 3c
tic
[i j] = meshgrid(1:500, 1:300);
a3 = (i.^2 + j.^2) ./ (i + j + 3);
threeCElapsed = toc;

t = table(["3a"; threeAElapsed], ["3b"; threeBElapsed], ["3c"; threeCElapsed]);