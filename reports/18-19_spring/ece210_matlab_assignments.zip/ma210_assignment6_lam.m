% MA210 Assignment 6 -- Jonathan Lam
clc;clear all;close all;

% 1: Discrete system with given transfer function
figure;
sgtitle('1. Discrete system with transfer function $$H(z)=\frac{\frac 12+\frac 23z+\frac 37z^2}{2+\frac 13z+\frac 12z^3}$$', 'interpreter', 'latex');

% 1a. Plotting transfer function
num = [3/7 2/3 1/2];
denom = [1/2 0 1/3 2];
subplot(2, 2, 1);
zplane(num, denom);
title('Pole zero plot of transfer function');

% 1b. Using impz
subplot(2, 2, 2);
impz(num, denom, 50);
title('Impulse response of transfer function');

% 1c. Using a filter
n = 1:99;
x = (-3/4).^n;
filtered = filter(num, denom, x);
subplot(2, 2, 3);
stem(filtered);
title('Impulse response with filter $$x=\left(-\frac 34\right)^n$$', 'interpreter', 'latex');

% 1d. Getting the same result w/o a filter
[h t] = impz(num, denom, 100);
convolution = conv(x, h);
subplot(2, 2, 4);
stem(convolution(1:99,1));
title('Applying filter using convolution');

% 2. Discrete system with fibonacci series as impulse response
figure;
sgtitle('2. Discrete system with fibonacci series as impulse response');

% 2a. Creating and plotting fibonacci series
n = 1:100;
fib = ones(1, length(n));
for i = 3:length(n)
   fib(i) = fib(i-2) + fib(i-1);
end
subplot(1, 2, 1);
semilogy(n, fib);
title('Semi-log plot of fibonacci series');
xlabel('n');
ylabel('fib(n)');

% 2b. Finding output of a system with impulse response fib
convolution = conv(x, fib);
subplot(1, 2, 2);
stem(convolution);
title('Output of system with impulse response fibonacci series');