from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
from urlparse import parse_qs
from datetime import datetime
import json
import cgi
import sqlite3

class GP(BaseHTTPRequestHandler, object):
    def __init__(self, *args):
        self.cursor = sqlite3.connect('messages.db', isolation_level=None).cursor()
        super(GP, self).__init__(*args)

    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()

    def do_HEAD(self):
        self._set_headers()

    def do_GET(self):
        self._set_headers()
        queryParms = parse_qs(self.path[2:])
        if 'user' in queryParms:
            receiver = queryParms['user'][0]
            
            messages = []
            for date, sender, message in self.cursor.execute('SELECT date, sender, message FROM msg WHERE receiver=?', (receiver, )):
                messages.append({'date': date, 'sender': sender, 'message': message})

            self.wfile.write('{"response": {"user": "%s", "messages": %s}}' % (receiver, json.dumps(messages)))
        else:
            self.wfile.write('{"error":"missing user field"}')

    def do_POST(self):
        self._set_headers()
        form = cgi.FieldStorage(
            fp = self.rfile,
            headers = self.headers,
            environ = { 'REQUEST_METHOD': 'POST' }
        )
        sender = form.getvalue('sender')
        receiver = form.getvalue('receiver')
        message = form.getvalue('message')
        if sender==None or receiver==None or message==None:
            self.wfile.write('{"response":{"error":"missing field"}}')
            return

        # assume valid inputs, insert into db
        self.cursor.execute('INSERT INTO msg (date, sender, receiver, message) VALUES (?, ?, ?, ?)',
                (datetime.now(), sender, receiver, message))

        self.wfile.write('{"response":"SUCCESS"}')

def run(server_class=HTTPServer, handler_class=GP, port=80):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print 'Server running at localhost:%d...' % port
    httpd.serve_forever()

run()
