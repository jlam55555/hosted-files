#ifndef GRAPH_H
#define GRAPH_H

#include <cmath>
#include <list>
#include <ostream>
#include <string>
#include "hash.h"
#include "heap.h"

class graph {
public:
    // addEdge used for inserting vertices, edges into graph
    void addEdge(std::string v1Id, std::string v2Id, int distance);

    // set start vertex; returns 1 if vertex doesn't exist, 0 for success
    int setStartVertex(std::string vStartId);

    // dijkstra's algorithm; returns early and prints err if no vStart
    void dijkstra();

private:
    class vertex {
    public:
        inline explicit vertex(std::string label) : label{label} {}

        // addEdge used for loading adjacency list
        void addEdge(vertex *vTo, int distance);

        // getters/setters (inlined because simple)
        inline std::string getLabel() const { return label; };
        inline void setVPrev(vertex *newVPrev) { vPrev = newVPrev; };
        inline vertex *getVPrev() const { return vPrev; };
        inline bool getIsKnown() const { return isKnown; };

        // for graph printing
        std::string toString() const;

        // processing a node in dijkstra's algorithm
        void dijkstraNode(heap &vertexHeap, int vDistance);
    private:
        // edge members are all public to make accessing simpler
        class edge {
        public:
            inline edge(vertex *vTo, int distance)
                : vTo{vTo}, distance{distance} {};
            vertex *vTo;
            int distance;
        };

        // noted differences from textbook: known is not used (existence in
        // vertexHeap is equivalent) and distance is only stored here after
        // it is removed from vertexHeap (otherwise, its distance is read
        // from vertexHeap)
        std::string label;
        int distance = static_cast<int>(INFINITY);
        bool isKnown = false;
        std::list<edge> adjList;
        vertex *vPrev = nullptr;
    };

    // getVertex, getVertexInsertIfNecessary return a vertex with the given
    // vId. getVertexInsertIfNecessary will insert it into the graph if it
    // doesn't exist.
    vertex *getVertex(std::string vId) const;
    vertex *getVertexInsertIfNecessary(std::string vId);

    // vertexMap used for fast lookup of vertices by id
    hashTable vertexMap{1000};

    // vertexList stores the vertices. vertexMap and vertexHeap use pointers
    // to the locations of a vertex in vertexList
    std::list<vertex> vertexList{};

    // start vertex, used for dijkstra's algorithm
    vertex *vStart = nullptr;

    // used for printing
    std::string toString() const;
    inline friend std::ostream &operator<<(std::ostream& os, const graph &g) {
        return os << g.toString();
    }
};

#endif //GRAPH_H
