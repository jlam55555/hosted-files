clc; clear; close all;

load('s1.mat');
load('s5.mat');
load('vowels.mat');

%% testing out the spectrogram function
spectrogram(s1, hamming(256), 255, 'yaxis');

%% Q1: chirp signal
mu = 4e9;
duration = 200e-6;
fs = 5e6;
N_fft = 256;
N_overlap = 255;

t = 0:(1/fs):duration;
x = cos(2 * pi * mu * t.^2);

figure('visible', 'off', 'position', [0 0 600 400]);
spectrogram(x, triang(N_fft), N_overlap, 'yaxis');
exportgraphics(gca(), 'chirp_spectrogram.pdf');

%% Q2: instantaneous frequency of the chirp signal
figure('visible', 'off', 'position', [0 0 600 400]);

hold on;
% plotting spectrogram as a surface
[s, w, t] = spectrogram(x, triang(256), 255, 'yaxis');
h = surf(t, w/pi, abs(s));
set(h, 'LineStyle', 'none');

% plotting first interpretation of inst. frequency (correct)
t = 0:(1/fs):duration;
x1 = t * fs / 2 / pi;
y1 = 2 * mu * t / fs * 2 * pi;
f = plot(x1, y1/pi);

% plotting second interpretation of inst. frequency (incorrect)tightlayout
t = 0:(1/fs):duration;
x1 = t * fs / 2 / pi;
y1 = mu * t / fs * 2 * pi;
f = plot(x1, y1/pi);
hold off;

xlabel('Samples');
ylabel('Normalized frequency (\times\pi radians/sample)');
ylim([0 1]);
exportgraphics(gca(), 'chirp_slope.pdf');

%% Q3: chirp signal with higher mu
mu2 = 1e10;
x2 = cos(2 * pi * mu2 * t.^2);

figure('visible', 'off', 'position', [0 0 600 400]);
spectrogram(x2, triang(256), 255, 'yaxis');
exportgraphics(gca(), 'chirp_spectrogram2.pdf');

%% Q4, Q5: narrow- and wideband analysis of speech
figure('position', [0 0 1200 800]);
tiledlayout(2, 2);

nexttile();
spectrogram(s1, triang(64), 63, 'yaxis');
title('S1.mat fundamental frequencies (winlen=64)');

nexttile();
spectrogram(s1, triang(1024), 1023, 'yaxis');
title('S1.mat formant frequencies (winlen=1024)');

nexttile();
spectrogram(s5, triang(128), 127, 'yaxis');
title('S2.mat fundamental frequencies (winlen=128)');

nexttile();
spectrogram(s5, triang(1024), 1023, 'yaxis');
title('S2.mat formant frequencies (winlen=1024)');

exportgraphics(gcf(), 'wide_narrow_band_speech.pdf');

%% Q6: modified STFTs
win_len = 256;
overlap_len = 128;
fft_len = 1024;
vowels_sgram = spectrogram(vowels, rectwin(win_len), overlap_len, fft_len);

%%
vowels_reconstructed = stft2sig(vowels_sgram, win_len, overlap_len);

%%
soundsc(vowels, 8e3);

%%
soundsc(vowels_reconstructed);

%% Q7: modify spectrogram
vowels_sgram_faster = vowels_sgram(:, 1:2:size(vowels_sgram, 2));
vowels_reconstructed_faster = stft2sig(vowels_sgram_faster, win_len, overlap_len);

%%
soundsc(vowels_reconstructed_faster);