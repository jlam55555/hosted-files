import requests

class MessageClient:
    def __init__(self, username, server_url):
        self.username = username
        self.server_url = server_url
        self.messages = self._get_messages()
        self._init_text()

    def _init_text(self):
        print """
Message Client v0.0.1 by Jonathan Lam.
Type "help" to see a list of available commands.
        """
        self._print_messages(self.messages)

    def prompt(self):
        command = raw_input('%s> ' % self.username)
        if command=='quit':
            return False
        elif command=='help':
            print """
+-----------------+
| Message client  |
| v0.0.1          |
| by Jonathan Lam |
+-----------------+
Commands:
- help                          display this help menu
- refresh                       show new messages
- send:<receiver>:<message>     send a message <message> to <receiver>
- quit                          exit message client
            """
        elif command=='refresh':
            self._print_messages(self._get_message_diff())
        elif command.startswith('send'):
            # assume text or username cannot contain colons
            parts = command.split(':')
            if not (len(parts)==3):
                print 'Usage: send:<receiver>:<message>'
                return True
            _, receiver, message = command.split(':')
            if len(receiver)==0 or len(message)==0:
                print 'Usage: send:<receiver>:<message>'
                return True
            self._send_message(receiver, message)
        return True

    def _print_messages(self, messages):
        if len(messages)==0:
            print "No messages here"
        for message in messages:
            self._print_message(message)
        print '====='

    def _print_message(self, message):
        print """=====
Sender:     %s
Date:       %s
Message:    %s""" % (message['sender'], message['date'], message['message'])

    def _get_message_diff(self):
        oldMessageCount = len(self.messages)
        self.messages = self._get_messages()
        return self.messages[oldMessageCount:]

    def _get_messages(self):
        res = requests.get('http://%s?user=%s' % (self.server_url, self.username))\
            .json()['response']
        if 'error' in res:
            print 'Error getting messages: %s' % res['error'] 
            return []
        return res['messages']

    def _send_message(self, receiver, message):
        res = requests.post('http://%s' % (self.server_url,), data={
            'sender': self.username,
            'receiver': receiver,
            'message': message
        }).json()['response']
        if 'error' in res:
            print 'Error sending message: %s' % res['error'] 

# main method: get username, initiate client prompt loop
if __name__=='__main__':
    server_url = raw_input('Server (url or ip): ')
    username = raw_input('Username: ')
    messageClient = MessageClient(username, server_url)

    while True:
        if messageClient.prompt()==False:
            break
