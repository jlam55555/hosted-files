% MA210 Assignment 5 -- Jonathan Lam
clc;clear all;close all;

% load fisher iris dataset
load fisheriris;

% create an object for each flower
for i = 1:length(species)
   flowers(i) = Flower(meas(i, 1), meas(i, 2), meas(i, 3), meas(i, 4), strtrim(species{i, 1})); 
end

% sample usages of methods
sampleSLength = flowers(25).getSLength();
flowers(25).report();