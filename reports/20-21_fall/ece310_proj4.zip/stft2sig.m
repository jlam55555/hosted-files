% Given a modified STFT, estimate the signal (perform an estimate
% of the inverse Fourier transform, even if the STFT is not valid)
%
% This function is implemented more generally than the problem set asks
% for.
%
% params:
% mod_stft      = modified STFT
% win_len       = length of window
% overlap_len   = length of window overlap
%
% returns:
% stft          = corrected stft
function stft = stft2sig(mod_stft, win_len, overlap_len)
    % infer FFT length and samples from STFT dimensions; note that
    % this FFT length is equal to half what it should be plus one
    % due to the nature of the spectrogram command
    [fft_len, samples] = size(mod_stft);
    fft_len = (fft_len-1) * 2;
    
    % non-overlap length
    nol = win_len - overlap_len;
    
    % augment STFT with negative frequencies
    mod_stft = [mod_stft(1:end-1, :); flip(mod_stft(2:end, :))];
    
    % take IFFT columnwise
    ifft_sig = real(ifft(mod_stft, fft_len, 1));

    % output array contains the results, as well as counting the number
    % of overlaps for the averaging process; probably a more efficient
    % way to do this but this is pretty general
    results = zeros(win_len + (samples-1) * nol, 2);
    
    % grab each sample, add it to the correct position, and increase
    % the overlap count for those samples
    for i = 1:samples
        current_range = ((i-1)*nol+1):((i-1)*nol+win_len);
        results(current_range, :) ...
            = [ifft_sig(1:win_len, i), ones(win_len, 1)] ...
            + results(current_range, :);
    end
    
    % return averaged samples (each sample is divided by its count)
    stft = results(:, 1) ./ results(:, 2);
end