% modulates a signal using the PM scheme
% params:
% f_c   = frequency of carrier
% A_c   = amplitude of carrier
% sig_m = message signal
% k     = k_p, phase deviation coefficient
% f_s_m = downsampled sampling rate
% f_s_c = updampled sampling rate
% returns:
% sig_c = PM-modulated signal at upsampled rate
function sig_c = pm_mod(f_c, A_c, sig_m, k, f_s_m, f_s_c)
    duration = length(sig_m) / f_s_m;
    t_m = linspace(0, duration, length(sig_m));
    t_c = linspace(0, duration, f_s_c * duration);
    
    % upsample sig_m, multiply by k to get phase
    sig_phi = k * interp1(t_m, sig_m, t_c);
    
    % generate phase-modulated signal w/ pilot tone
    A_p = 1;
    sig_c = A_c * cos(2 * pi * f_c * t_c + sig_phi) ...
          + A_p * cos(2 * pi * f_c * t_c);
end