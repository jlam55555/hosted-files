#ifndef _HEAP_H
#define _HEAP_H

#include "hash.h"

class heap {

public:

    // heap - The constructor allocates space for the nodes of the heap
    // and the mapping (hash table) based on the specified capacity
    explicit inline heap(int capacity)
        : capacity{capacity}, data(capacity+1), nodeMap{((capacity+1)*2)} {}

    // insert - Inserts a new node into the binary heap
    //
    // Inserts a node with the specified id string, key,
    // and optionally a pointer. They key is used to
    // determine the final position of the new node.
    // Returns:
    //   0 on success
    //   1 if the heap is already filled to capacity
    //   2 if a node with the given id already exists (but the heap
    //     is not filled to capacity)
    int insert(const std::string &id, int key, void *pv = nullptr);

    // setKey - set the key of the specified node to the specified value
    //
    // I have decided that the class should provide this member function
    // instead of two separate increaseKey and decreaseKey functions.
    // Returns:
    //   0 on success
    //   1 if a node with the given id does not exist
    int setKey(const std::string &id, int key);

    // deleteMin - return the data associated with the smallest key
    //             and delete that node from the binary heap
    //
    // If pId is supplied (i.e., it is not NULL), write to that address
    // the id of the node being deleted. If pKey is supplied, write to
    // that address the key of the node being deleted. If ppData is
    // supplied, write to that address the associated void pointer.
    // Returns:
    //   0 on success
    //   1 if the heap is empty
    int deleteMin(std::string *pId = nullptr, int *pKey = nullptr,
                  void *ppData = nullptr);

    // remove - delete the node with the specified id from the binary heap
    //
    // If pKey is supplied, write to that address the key of the node
    // being deleted. If ppData is supplied, write to that address the
    // associated void pointer.
    // Returns:
    //   0 on success
    //   1 if a node with the given id does not exist
    int remove(const std::string &id, int *pKey = nullptr,
               void *ppData = nullptr);

    // getKey - convenience function to get key of specific element (without
    // removal), used for dijkstra algorithm
    //
    // Returns:
    //   0 on success
    //   1 if a node with the given id does not exist
    int getKey(const std::string &id, int *pKey) const;

private:

    // heapNode - store an individual element in the heap
    class heapNode {
    public:
        std::string id;
        int key;
        void *pv = nullptr;
    };

    // capacity - maximum (fixed) capacity of the heap
    int capacity;

    // currentSize - number of elements in the heap
    int currentSize = 0;

    // data - storing all of the heapNode elements
    std::vector<heapNode> data;

    // nodeMap - maps ids to nodes, used for fast setKey, remove
    hashTable nodeMap;

    // percolateDown, percolateUp - move the given node up or down in the heap
    // to the position that correctly maintains heap order. This also updates
    // all of the affected pointers in nodeMap.
    void percolateDown(heapNode *node);
    void percolateUp(heapNode *node);
};

#endif // _HEAP_H
