#include "heap.h"

// insert a node: create node, insert at end, percolate up
int heap::insert(const std::string &id, int key, void *pv) {
    heapNode *node;

    if(currentSize == capacity)
        return 1;

    if(nodeMap.contains(id))
        return 2;

    node = &data[++currentSize];
    node->id = id;
    node->key = key;
    node->pv = pv;

    nodeMap.insert(id, node);
    percolateUp(node);

    return 0;
}

// setKey finds node, updates key
int heap::setKey(const std::string &id, int key) {
    heapNode *node;
    int oldKey, ind;

    if(!nodeMap.contains(id))
        return 1;

    // choose between percolate up or down
    node = static_cast<heapNode *>(nodeMap.getPointer(id));
    oldKey = node->key;
    node->key = key;
    if(oldKey < key)
        percolateDown(node);
    else if(oldKey > key)
        percolateUp(node);

    return 0;
}

// deleteMin gets and returns node data, and replaces it with last element
// (then percolating it down)
int heap::deleteMin(std::string *pId, int *pKey, void *ppData) {
    heapNode *node;
    std::string id;

    if(currentSize == 0)
        return 1;

    // set data
    node = &data[1];
    id = node->id;
    if(pId != nullptr)
        *pId = id;
    if(pKey != nullptr)
        *pKey = node->key;
    if(ppData != nullptr)
        *static_cast<void **>(ppData) = node->pv;

    data[1] = std::move(data[currentSize--]);
    percolateDown(&data[1]);

    // remove from node map
    nodeMap.remove(id);

    return 0;
}

// remove swaps with element at end, percolates up/down as necessary with setKey
// more efficient than doing percolateUp and then deleteMin (two percolates)
int heap::remove(const std::string &id, int *pKey, void *ppData) {
    heapNode *node;

    if(!nodeMap.contains(id))
        return 1;

    node = static_cast<heapNode *>(nodeMap.getPointer(id));
    if(pKey != nullptr)
        *pKey = node->key;
    node->key = data[1].key - 1;

    std::swap(*node, data[currentSize--]);
    nodeMap.setPointer(node->id, node);
    return setKey(node->id, node->key);
}

// percolateDown moves node down in tree (replacing "holes" with smaller child)
// until children are larger to fix heap order. Pointers to moved nodes are
// updated in nodeMap
void heap::percolateDown(heap::heapNode *node) {
    // hole is index of node
    int hole = node - &data[0],
        child,
        key = node->key;

    // data[0] used as temporary storage place
    data[0] = std::move(*node);
    for( ; hole << 1 <= currentSize; hole = child) {
        child = hole << 1;

        // choose smaller child
        if(child != currentSize && data[child+1].key < data[child].key)
            child++;

        if(data[child].key < key) {
            data[hole] = std::move(data[child]);
            nodeMap.setPointer(data[hole].id, &data[hole]);
        } else
            break;
    }
    data[hole] = std::move(data[0]);
    nodeMap.setPointer(data[hole].id, &data[hole]);
}

// getKey simply returns the key
int heap::getKey(const std::string &id, int *pKey) const {
    if(!nodeMap.contains(id))
        return 1;

    *pKey = static_cast<heapNode *>(nodeMap.getPointer(id))->key;
    return 0;
}

// percolateUp moves node up in tree (replacing "holes" with parent) until
// parent is smaller to fix heap order. Pointers to moved nodes are updated
// in nodeMap
void heap::percolateUp(heap::heapNode *node) {
    // hole is index of node
    int hole = node - &data[0],
        key = node->key;

    data[0] = std::move(*node);
    for( ; key < data[hole >> 1].key; hole >>= 1) {
        data[hole] = std::move(data[hole >> 1]);
        nodeMap.setPointer(data[hole].id, &data[hole]);
    }
    data[hole] = std::move(data[0]);
    nodeMap.setPointer(data[hole].id, &data[hole]);
}
