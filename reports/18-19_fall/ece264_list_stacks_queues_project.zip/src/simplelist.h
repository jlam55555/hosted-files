// preprocessor commands to avoid redefinition
#ifndef simplelist_defined
#define simplelist_defined 1

#include <string>

/** SimpleList template class; acts as a linkedlist
  * 
  * A pointer is kept to the starting element (*start) and final element (*end). There are no sentinel nodes; this creates some pecularities outlined in the description of the implementations of insert_at_start, insert_at_end, and remove_from_start).
  * When the list is empty, both start and end point to NULL. (This can be used to easily check for emptiness.)
  * 
  * To insert at start:
  * - Create a new Node, have it point to current start
  * - Point start at the new Node
  * - If list was empty before (if end points to NULL), point end to new Node as well
  *
  * To insert at end:
  * - Create a new Node, have it point to NULL
  * - If list is empty, point start and end to the new Node
  * - Else point current end Node to new Node
  *
  * To remove from start:
  * - If list is empty, return
  * - Get value of first Node
  * - If list has only one element (if first Node points to NULL), delete first element, point start and end to NULL
  * - Else point start to second Node, delete first Node
  * - Return the value of what was first Node
  */
template <class T>
class SimpleList {
  private:
    class Node {
      private:
        T value;
        Node *next;
      public:
        Node(T value, Node *next);
        void set_next(Node *next);
        T get_value();
        Node *get_next();
    };
    Node *start;
    Node *end;
    std::string name;
  protected:
    void insert_at_start(T element);
    void insert_at_end(T element);
    T remove_from_start();
  public:
    SimpleList(std::string name);
    const std::string get_name();
    const int is_empty();
    virtual void push(T element) = 0;
    virtual T pop() = 0;
};

// linkedlist Node class; has setter and getters for SimpleList
template <class T>
SimpleList<T>::Node::Node(T value, SimpleList<T>::Node *next) {
  this->value = value;
  this->next = next;
}
template <class T>
void SimpleList<T>::Node::set_next(SimpleList<T>::Node *next) {
  this->next = next;
}
template <class T>
T SimpleList<T>::Node::get_value() {
  return this->value;
}
template <class T>
typename SimpleList<T>::Node *SimpleList<T>::Node::get_next() {
  return this->next;
}

// main functionality methods: see description at top for details
template <class T>
SimpleList<T>::SimpleList(std::string name) {
  this->name = name;
  this->start = NULL;
  this->end = NULL;
}
template <class T>
void SimpleList<T>::insert_at_start(T element) {
  this->start = new Node(element, this->start);
  if(this->is_empty()) {
    this->end = this->start;
  }
}
template <class T>
void SimpleList<T>::insert_at_end(T element) {
  if(this->is_empty()) {
    this->end = new Node(element, NULL);
    this->start = this->end;
  } else {
    this->end->set_next(new Node(element, NULL));
    this->end = this->end->get_next();
  }
}
template <class T>
T SimpleList<T>::remove_from_start() {
  if(this->is_empty()) {
    return T();
  }
  T value = this->start->get_value();
  if(this->start->get_next() == NULL) {
    delete this->start;
    this->start = NULL;
    this->end = NULL;
  } else {
    Node *second_node = this->start->get_next();
    delete this->start;
    this->start = second_node;
  }
  return value;
}

// helper/convenience functions: get name and check if empty
template <class T>
const std::string SimpleList<T>::get_name() {
  return this->name;
}
template <class T>
const int SimpleList<T>::is_empty() {
  return this->end == NULL;
}

#endif
