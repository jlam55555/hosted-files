% modulates a signal using the conventional AM scheme
% params:
% f_c   = frequency of carrier (Hz)
% A_c   = carrier amplitude
% a     = modulation index
% sig_m = message signal
% f_s_m = message sampling frequency (Hz)
% f_s_c = carrier sampling frequency (Hz)
% returns:
% sig_c = conventional AM-modulated signal
function sig_c = conv_mod(f_c, A_c, a, sig_m, f_s_m, f_s_c)
    duration = length(sig_m) / f_s_m;
    t_m = linspace(0, duration, length(sig_m));
    t_c = linspace(0, duration, f_s_c * duration);
    
    % upsample sig_m
    sig_m_us = interp1(t_m, sig_m, t_c);
    
    % generate conventional AM-modulated signal
    sig_c = A_c * (1 + sig_m_us * a) .* cos(2 * pi * f_c * t_c);
end