% MA210 Assignment 4 -- Jonathan Lam
clc;clear all;close all;

% PART 1: GRAM SCHMIDT ORTHONORMALIZATION

% number of vectors (and generally the number of elements per vector)
testSize = 5;
% epsFudgeFactor is larger depending on size of test vectors
epsFudgeFactor = 10 * testSize * eps();

% function to check if all vectors in set are orthonormal
% inspiration for checking mutual orthonormality from
% https://math.stackexchange.com/a/2194971/96244
isOrthonormal = @(vectors) isequal(vectors' * vectors - eye(size(vectors, 2)) <= epsFudgeFactor, true(size(vectors, 2)));

% function for estimating a vector wrt orthonormal basis
% does projections by dot product
orthoProj = @(vector, basis) basis * (basis' * vector);

% test vector
testVector = rand(testSize, 1);

% a is a set of vectors with more elements per vector than vectors
a = rand(testSize, testSize - 2);
aBasis = gramSchmidt(a);
isABasisOrthonormal = isOrthonormal(aBasis);
aEstimate = orthoProj(testVector, aBasis);

% b is a set of vectors with as many elemnts per vector as vectors
b = rand(testSize, testSize);
bBasis = gramSchmidt(b);
isBBasisOrthonormal = isOrthonormal(bBasis);
bEstimate = orthoProj(testVector, bBasis);

% checking absolute error
% aEstimate is generally a little shorter than the real length
% bEstimate should be pretty much exact
aNormError = norm(aEstimate - testVector)
bNormError = norm(bEstimate - testVector)

% PART 2: GAUSSIANS
sineX = 0:0.01:2*pi;
sineY = sin(sineX);
mean = 0:pi/2:2*pi;
stdev = 1;

% gaussian = @(x, sigma, mu) (2 * pi * sigma^2)^-0.5 .* exp(-(x - mu).^2 ./ sigma^2);
[x, y] = ndgrid(sineX, mean);
gaussians = (2 * pi * stdev^2)^-0.5 .* exp(-(x - y).^2 ./ stdev^2);

% plot the sine fn and the gaussians
figure;
plot(sineX, sineY);
hold on;
plot(x, gaussians);
title('Sinusoid and Gaussian Functions');
xlabel('-2\pi < x < 2\pi');
ylabel('Sine and Gaussian Values');
legend('sine', 'gaussian1', 'gaussian2', 'gaussian3', 'gaussian4', 'gaussian5');
hold off;

% get orthonormal set from gaussians and estimate sinusoid
gaussianBasis = gramSchmidt(gaussians);
sineEstimate = orthoProj(sineY', gaussianBasis);

figure;
sp1 = subplot(2, 1, 1);
hold on;
plot(sp1, sineX, sineY);
plot(sp1, sineX, sineEstimate);
title(sp1, 'Sinusoid and Approximation with Gaussian Basis');
xlabel(sp1, '-2\pi < x < 2\pi');
ylabel(sp1, 'Sine and Estimate');
hold off;

sp2 = subplot(2, 1, 2);
plot(sp2, sineX, gaussianBasis);
title(sp2, 'Gaussian Basis Vectors');
xlabel(sp2, '-2\pi < x < 2\pi');
ylabel(sp2, 'Gaussian Basis');

% function for finding the basis using the gram schmidt method
% couldn't write this as lambda
function basis = gramSchmidt(vectors)
    for i = 1:size(vectors, 2)
        vi = vectors(:, i);
        for j = 1:i-1
            % this comes from projection = (vi dot uj) times uj
            vi = vi - vi' * basis(:, j) * basis(:, j);
        end
        basis(:, i) = vi / norm(vi);
    end
end