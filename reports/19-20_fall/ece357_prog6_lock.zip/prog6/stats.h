#ifndef __STATS_H
#define __STATS_H
#include "spinlock.h"

extern struct stats *stats;
struct stats {
  spinlock_t lock;
  unsigned int att_seqlock_read, suc_seqlock_read, net_dll_len_chg;
};
#endif
