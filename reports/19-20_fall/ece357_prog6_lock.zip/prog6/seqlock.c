#include <sched.h>
#include "seqlock.h"

// This implementation closely follows the lecture notes. I didn't experience
// issues with non-atomic count incrementing, so didn't protect the field
// with a spinlock.

void write_seqlock(struct seqlock *s) {
  spin_lock(&s->lock);
  s->count++;
}
void write_sequnlock(struct seqlock *s) {
  s->count++;
  spin_unlock(&s->lock);
};
int read_seqbegin(struct seqlock *s) {
  int a;
  while((a=s->count)%2)
    sched_yield();
  return a;
}
int read_seqretry(struct seqlock *s, int orig) {
  return s->count!=orig;
}

