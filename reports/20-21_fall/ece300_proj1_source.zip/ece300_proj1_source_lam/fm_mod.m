% modulates a signal using the FM scheme
% params:
% f_c   = frequency of carrier
% A_c   = amplitude of carrier
% sig_m = message signal
% k     = k_f, frequency deviation coefficient
% f_s_m = downsampled sampling rate
% f_s_c = updampled sampling rate
% returns:
% sig_c = FM-modulated signal at upsampled rate
function sig_c = fm_mod(f_c, A_c, sig_m, k, f_s_m, f_s_c)
    duration = length(sig_m) / f_s_m;
    t_m = linspace(0, duration, length(sig_m));
    t_c = linspace(0, duration, f_s_c * duration);
    
    % upsample sig_m, multiply by k, integrate and multiply by 2pi to get
    % phase (in rad)
    sig_phi = 2 * pi * k * interp1(t_m, cumsum(sig_m) / f_s_m, t_c);
    
    % generate phase-modulated signal (since FM is basically PM)
    sig_c = A_c * cos(2 * pi * f_c * t_c + sig_phi);
end