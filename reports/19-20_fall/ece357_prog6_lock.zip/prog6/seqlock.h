#ifndef __SEQLOCK_H
#define __SEQLOCK_H
#include "spinlock.h"

struct seqlock {
  spinlock_t lock;
  int count;
};
void write_seqlock(struct seqlock *s);
void write_sequnlock(struct seqlock *s);
int read_seqbegin(struct seqlock *s);
int read_seqretry(struct seqlock *s, int orig);
#endif
