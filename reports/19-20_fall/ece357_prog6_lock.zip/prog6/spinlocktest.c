// usage: spinlocktest [thread_count] [sample_count]

#include <stdio.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include "errfat.h"
#include "spinlock.h"

#define THREAD_CNT_DFL 8
#define SAMPLE_CNT_DFL 100000
#define PROG "spinlocktest"

// generate spinlock test
void transact_nospinlock(int *p, int sample_cnt) {
  for(int i = 0; i < sample_cnt; i++)
    (*p)++;
}
void transact_spinlock(int *p, spinlock_t *sl, int sample_cnt) {
  for(int i = 0; i < sample_cnt; i++) {
    spin_lock(sl);
    (*p)++;
    spin_unlock(sl);
  }
}
void generate_spinlock_test(int use_spinlock, int thread_cnt, int sample_cnt) {
  int *p, i, wstatus, pid;
  spinlock_t *sl;
  
  // create shared mmap region; first (sizeof(int)) bytes for data to rapidly
  // change, and last (sizeof(char)) bytes for spinlock
  if((p = (int *)mmap(NULL,sizeof(int)+sizeof(spinlock_t),PROT_READ|PROT_WRITE,
                       MAP_SHARED|MAP_ANONYMOUS, -1, 0)) == MAP_FAILED)
    ERRNO_FAT("mmap", "shared region");
  sl = (spinlock_t *)(p+1);
  
  // create thread_cnt processes; do sample_cnt transactions in each child,
  // don't do anything in parent
  for(i=0; i<thread_cnt; i++)
    switch(fork()) {
    case -1:
      ERRNO_FAT("fork", i);
    case 0:
      if(use_spinlock)
        transact_spinlock(p, sl, sample_cnt);
      else
        transact_nospinlock(p, sample_cnt);
      exit(EXIT_SUCCESS);
    }

  // aggregate results and cleanup; ignore wstatus
  for(i=0; i<thread_cnt; i++)
    if(pid=wait(&wstatus)<0)
      ERRNO_FAT("wait", pid);
  dprintf(2, "%d\n", *p);
  if(munmap(p, sizeof(int)+sizeof(spinlock_t))<0)
    ERRNO_FAT("munmap", "shared region");
}
int main(int argc, char **argv) {
  int thread_cnt, sample_cnt;
  if(argc<3) {
    thread_cnt = THREAD_CNT_DFL;
    sample_cnt = SAMPLE_CNT_DFL;
  } else {
    thread_cnt = atoi(argv[1]);
    sample_cnt = atoi(argv[2]);
  }

  dprintf(1, "Processes:\t%d\nSamples/proc:\t%d\nExpected total:\t%d\n---\n",
          thread_cnt, sample_cnt, thread_cnt*sample_cnt);
  dprintf(1, "w/o spinlock:\t");
  generate_spinlock_test(0, thread_cnt, sample_cnt);
  dprintf(1, "w/ spinlock:\t");
  generate_spinlock_test(1, thread_cnt, sample_cnt);
}
